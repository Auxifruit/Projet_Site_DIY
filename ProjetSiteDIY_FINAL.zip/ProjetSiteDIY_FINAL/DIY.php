<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="DIY.css" rel="stylesheet">
    <title>Liste DIY</title>
</head>
<body>
    <?php 
        include_once 'haut_page.php';
        include_once 'API/lib/DIYUtils.php';
    ?>

    <div id=boite>

        <ul id="dd">
            
            <div class='vide'> </div>
                
                <?php
                    $tabid=getToutIdDIY();

                    if(!empty($tabid)) {
                        for ($i = 0; $i <(count($tabid)) ; $i++) {
                        $valdiy = getInfoDIY($tabid[$i]);
    
                        $nom = $valdiy[1];
                        $createur = $valdiy[2];
                        $duree = $valdiy[3];
                        $note = $valdiy[8];
                        $diff = $valdiy[4];
                        $img = $valdiy[5];
                        $Id = $valdiy[0];
                        $exp = $valdiy[6];

                        echo "<li class='ligne'>
                            <img class='photo' src='".$img."'>
                            <div class='nom_note_diff_duree_bouton'>
                                <div class='nom'><h3><u>Nom du DIY:</u> ".$nom."</h3></div>
                                <div class='note_diff_duree'>
                                    <div class='note'><u>Note:</u> ".$note."/5</div>
                                    <div class='diff'><u>Difficulté:</u> ".$diff."/5</div>
                                    <div class='duree'><u>Duree:</u> ".$duree." minutes</div>
                                </div>
                                <a href='DIY_recette.php?Id=".$Id."'><button class='bouton'>Accéder au DIY</button></a>
                            </div>
                        </li>";
                        }
                    }
                    else {
                        echo "<li class='info'>
                            <div id='rien'><h3><u>Il n'y a aucun DIY sur le site !</u></h3></div>
                            <span>Cliquez ici pour accéder à la page de création des DIY:</span>
                            <a href='DIY_ajout.php'><button class='bouton'>Ajouter DIY</button></a>
                        </li>";
                    }
                ?>
        </ul>
    </div>
</body>
</html>
