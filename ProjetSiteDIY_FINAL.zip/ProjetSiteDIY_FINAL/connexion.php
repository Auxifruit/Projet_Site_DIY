<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="identification.css">
    <title>Connexion</title>
    <script type="text/javascript" src="identification.js"></script>
</head>
<body>
    <?php include_once 'haut_page.php' ?>
    
    <div id="connexion">
        <h2 class="txt">Connectez-vous:</h2><br>
        <div id="bulle">
            <label class="txt">Identifiant:</label><br><br>
            <input type="text" id="id" name="id" placeholder="Entrez votre identifiant"><br><br>

            <label class="txt">Mot de passe:</label><br><br>
            <input type="password" id="mdp" name="mdp" placeholder="Entrez votre mot de passe"><br><br>
            
            <button type="buton" id="bouton" onclick="connexion()">Connexion</button><br><br>

            <span class="txt">Pas encore de compte ?</span> <a href="inscription.php">Inscivez-vous</a><br><br>

            <span id="erreur"></span>

        </div>
    </div>

    
    <script>
        document.addEventListener("keyup", function(event) {
            if (event.keyCode === 13) {
                connexion();
            }
        });
    </script>
    


</body>
</html>
