<?php
    include_once __DIR__."/master.php";
    include_once __DIR__."/DIY.php";
    include_once __DIR__."/utilisateurs.php";

    function ouvrire_hebdo()
    {
        return fopen(LOCA_HEBDO, "r+");
    }

    /**
     * Ecrit un utilisateur et un DIY au hasard ainsi que le dernier DIY rajouté
     */
    function ajouter_hebdo()
    {
        $flux = ouvrire_hebdo();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }
        
        // Retourne tout les DIYs et utilisateur afin d'en prendre un au hasard
        $utilisateurs = retourner_idUtilisateur();
        $utilisateurs_taille = sizeof($utilisateurs);

        $DIYs = retourner_idDIY();
        $DIYs_taille = sizeof($DIYs);

        $rand_utilisateurs = rand(0, $utilisateurs_taille <= 0 ? 0 : $utilisateurs_taille - 1);
        $rand_DIYs = rand(0, $DIYs_taille <= 0 ? 0 : $DIYs_taille - 1);

        $nouvel_info = implode(";", array($utilisateurs[$rand_utilisateurs], $DIYs[$rand_DIYs], $DIYs[$DIYs_taille - 1]));
        
        file_put_contents(LOCA_HEBDO, $nouvel_info);
        fclose($flux);
    }

    
    /** Fonction retournant les information hebdomadaire
     * @return mixed 0: ID de L'utilisateur 1: ID du DIY 2: ID Du dernier DIY ajouté
    */
    function recuperer_InfoHebdo()
    {
        $contenue = file_get_contents(LOCA_HEBDO);
        $collection = explode(";", $contenue);

        if(sizeof($collection) < 3)
        {
            message_erreur("IL MANQUE DES INFORMATION DANS LA BANQUE D'INFOMATION HEBDOMADAIRE !");
        }

        return $collection;
    }
?>