<?php
    // Importation des librairies
    include_once __DIR__."/master.php";
    include_once __DIR__."/DIY.php";

    function ouvrir_utilisateur()
    {
        return fopen(LOCA_UTILISATEUR, "r+"); 
    }


    // Ajoute un nouvel utilisateur en regardant si le Pseudo n'est pas déjà utilisé
    function ajouter_utilisateur($pseudo, $mdp, $lien_pp)
    {
        if(est_inscrit($pseudo))
        {
            return false;
        }

        // Enregistre le lien de la photo et verifie son existance
        $PP_verif = conversion_PP($lien_pp, LOCA_PP, $pseudo);
        if(!$PP_verif)
        {
            message_erreur("ECHEC LORS DE L'AJOUT LINK_PP->NULL");
        }

        // On ouvre le fichier et place le pointeur à sa fin
        $flux = ouvrir_utilisateur();
        fseek($flux, 0, SEEK_END);

        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }
        // Hash le mot de passe pour qu'il devienne encrypté
        $encry_mdp = hash(HASH_KEY, $mdp);
        fputcsv($flux, [$pseudo, $encry_mdp, 0, $PP_verif], ";");
        fclose($flux);
        
        return true;
    }

    // Cherche si un utilisateur est bien inscrit dans la base de donnée
    function est_inscrit($pseudo)
    {        
        return id_valide(LOCA_UTILISATEUR, $pseudo);
    }


    // Retourne le chemin vers la photo de profile
    function recupererCheminABS_PP($id)
    {
        $flux = ouvrir_utilisateur();
        $chemin = retournerCheminABS_Photo($id, $flux, 3);
        fclose($flux);

        if(is_file($chemin))
        {
            return array(true, $chemin);
        }
        return array(false, '');
    }
    
    // Compare le mdp en parametre avec le mdp present dans la base de donné
    function mdp_identique($pseudo, $mdp)
    {
        $flux = ouvrir_utilisateur();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        $ligne_actuel = recupererInfo_CSV($flux, $pseudo);
        fclose($flux);
        return ($ligne_actuel !== false && $ligne_actuel[1] == hash(HASH_KEY, $mdp));
    }


    /** Regarde le statut de l'utilisateur
     * @return mixed Retourne 'false' si la fonction ne s'est pas bien executé sinon retourne la valeur de l'importance 
    */
    function retourner_importance($pseudo)
    {
        $flux = ouvrir_utilisateur();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        $ligne_actuel = recupererInfo_CSV($flux, $pseudo);
        fclose($flux);

        if(!$ligne_actuel){return false;}
        return $ligne_actuel[2];
    }

    // Fonction retournant tout les id d'un utilisateur
    function retourner_idUtilisateur()
    {
        $flux = ouvrir_utilisateur();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        $collection = array();
        $ligne_actuel = false;

        while(!feof($flux))
        {
            $ligne_actuel = fgetcsv($flux, null, ";");
            if($ligne_actuel !== false && $ligne_actuel[0] != "")
            {
                array_push($collection, $ligne_actuel[0]);
            }
        }

        return $collection;
    }

    // Fonction retournant tout les DIY étant créee par un utilisateur
    function recupererDIYUtilisateur($pseudo)
    {
        if(!est_inscrit($pseudo))
        {
            return false;
        }

        $flux = ouvrire_DIY();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        $tableau_DIY = array();
        $ligne_actuel = false;


        while(!feof($flux))
        {
            $ligne_actuel = fgetcsv($flux, null, ";");
            if($ligne_actuel !== false && $ligne_actuel[2] == $pseudo)
            {
                // On rajoute l'id du DIY si son créateur est $pseudo
                array_push($tableau_DIY, $ligne_actuel[0]);
            }
        }

        fclose($flux);
        return $tableau_DIY;
    }

    // Fonction supprimant un utilisateur de la base de donnée ainsi que ses DIY et commentaires
    function supprimerUtilisateur($pseudo)
    {
        if(!est_inscrit($pseudo))
        {
            return false;
        }

        $DIYs = recupererDIYUtilisateur($pseudo);
        supprimerLigne_CVS(LOCA_UTILISATEUR, $pseudo);
        if(!$DIYs)
        {
            return true;
        }

        array_map("supprimerDIY", $DIYs);
        return true;
    }

    /** Fonction changeant l'importance de l'utilisateur lui donnant plus de droits ou non
    * @param string $importance 0: Utilisateur lambda 1: Admin 2: SuperAdmin 
    * @return bool Valeur de succès de la fonction
    */
    function changerImportance($pseudo, $importance)
    {
        $flux = ouvrir_utilisateur();
        $modification_possible = false;
        $ligne_actuel = false;

        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }
        
        while(!feof($flux))
        {
            $ligne_actuel = fgetcsv($flux, null, ";");
            if($ligne_actuel !== false && $ligne_actuel[0] == $pseudo)
            {
                $modification_possible = true;
                break;
            }
        }

        if(!$modification_possible)
        {
            fclose($flux);
            return false;
        }

        // On recule de 2 characètre avant de les changer
        fseek($flux, -(strlen($ligne_actuel[3]) + 3), SEEK_CUR);
        fwrite($flux, $importance);
        fclose($flux);

        return true;
    }


    /** Fonction changeant la photo de profil d'un utilisateur
     * @param string $nouvelle_photo Chemin vers la nouvel photo de l'utilisateur 
     * @return bool Valeur de succès
     */
    function changer_PP($pseudo, $nouvelle_photo)
    {
        if(!est_inscrit($pseudo)){return false;}

        $flux = ouvrir_utilisateur();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        if(!is_file($nouvelle_photo))
        {
            message_erreur("LE CHEMIN DE LA PHOTO N'EST PAS VALIDE");
        }

        $ancienne_ligne = recupererInfo_CSV($flux, $pseudo);
        fclose($flux);

        supprimerLigne_CVS(LOCA_UTILISATEUR, $pseudo);


        $ancienne_ligne[2] = conversion_PP($nouvelle_photo, LOCA_PP, $pseudo);
        $flux = ouvrir_utilisateur();
        if(!$flux)
        {
            // Si le flux est inccessible avant le reajout il faut reajouter l'utilisateur
            message_erreur("L'UTILISATEUR".$pseudo."À ÉTÉ SUPPRIMÉ MAIS PAS RÉAJOUTER VEUILLEZ LE RÉAJOUTER");
        }

        fseek($flux, 0, SEEK_END);
        fputcsv($flux, $ancienne_ligne, ";");

        return true;
    }
?>