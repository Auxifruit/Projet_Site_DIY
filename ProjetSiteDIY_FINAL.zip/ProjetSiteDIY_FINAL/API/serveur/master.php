<?php
    // Fichier regroupants les constantes et variables globales du programme
    if(!defined("ROOT"))
    {
        // Definition des constantes representant la position des fichiers
        define("ROOT", $_SERVER['DOCUMENT_ROOT']);
        define("LOCA_UTILISATEUR", ROOT."/data/utilisateur.txt");
        define("LOCA_DIY", ROOT."/data/DIY.txt");
        define("LOCA_RECETTE", ROOT."/data/recette.txt");
        define("LOCA_COMMENTAIRE", ROOT."/data/commentaires.txt");
        define("LOCA_EXPLICATION", ROOT."/data/explication/");
        define("LOCA_HEBDO", ROOT."/data/hebdo.txt");
        define("LOCA_COM_BDD", ROOT."/data/commentaires_BDD/");
        define("LOCA_EXP_BDD", ROOT."/data/explication_BDD/");
        define("LOCA_PP", ROOT."/data/PhotoProfil");
        define("LOCA_PDIY", ROOT."/data/PhotoDIY");
        define("HASH_KEY", "md5");
        define("FICHIER_NUL", "LE FICHIER EST INVALIDE"); 

        // Fonciton stoppant l'execution du programme et ferme tout les flux ouvert
        function message_erreur($type_err)
        {
            array_map('fclose', get_resources('stream'));
            throw new $type_err; 
        }

        // Retire le chemin absolue d'un chemin pour ne laisser que le chemin relatif
        function rongnerROOT($string)
        {
            if(!strpos($string, ROOT))
            {
                return substr($string, strlen(ROOT));
            }

            return $string;
        }

        /** Fonction servant à borner une valeur entre un majorant et un minorant
         * @param mixed $val La valeur
         * @param mixed $min Le minorant
         * @param mixed $max Le Majorant
         * @return mixed La valeur bornée
         */
        function clamp($val, $min, $max)
        {
            return max($min, min($val, $max));
        }
        // Fonction permettant de retourner toute les colones d'une ligne CSV
        function recupererInfo_CSV($flux, $valeur, $indice = 0)
        {
            if(!$flux)
            {
                message_erreur(FICHIER_NUL);
            }

            $ligne_actuel = false;
            while(!feof($flux))
            {
                $ligne_actuel = fgetcsv($flux, null, ";");
                if($ligne_actuel !== false && $ligne_actuel[$indice] == $valeur)
                {
                    return $ligne_actuel;
                }
            }

            return false;
        }

        function rechercheInfo_CSV($flux, $callback, $motClefs, $nbEchangeMax, $indiceValeur, ...$args){
            if(!$flux)
            {
                message_erreur(FICHIER_NUL);
                return false;
            }
    
            $ligne_actuel = "";
            $correspondance = "";
    
            $resultats = array();
            while(!feof($flux))
            {
                $ligne_actuel = fgetcsv($flux, null, ";");
    
                /* Appel la fonction $callback qui a été passé en paramètre
                 * Il est important que la fonction prenne en paramètre un tableau des différentes valeur du fichier CSV et les arguments de recherche
                 * et renvoi la même ligne avec pour première valeur l'indice de ressemblance.
                 *
                 */
                if($ligne_actuel !== false){
                    $correspondance = call_user_func($callback, $ligne_actuel, $motClefs, $nbEchangeMax, $indiceValeur, $args);
                    if($correspondance[0] < $correspondance[1]){
                        if(count($resultats) == 0){
                            array_push($resultats, $correspondance);
                        }else{
                            $i = 0;
                            while($i < count($resultats)){
                                if($resultats[$i][0] > $correspondance[0]){
                                    array_splice($resultats, $i, 0, 0);
                                    $resultats[$i] = $correspondance;
                                    $i = count($resultats);
                                }
                                $i++;
                            }
                            //Cas on le rajoute a la fin car c'est le plus grand
                            if($i == count($resultats)){
                                array_push($resultats, $correspondance);
                            }
                        }
    
                    }
                }
            }
    
            return $resultats;
        }
        
        // Fonction retournant la validité d'une ligne dans un flux
        function id_valide($loca_BBD, $id)
        {
            $flux = fopen($loca_BBD, "r+");
            if(!$flux)
            {
                message_erreur(FICHIER_NUL);
            }

            $resultat = recupererInfo_CSV($flux, $id) !== false;
            fclose($flux);
            return $resultat;
        }

        // Supprime une ligne d'un fichier en fonction de sa clef primaire
        function supprimerLigne_CVS($loca_fichier, $id)
        {
            $flux = fopen($loca_fichier, "r+");
            if(!$flux)
            {
                message_erreur(FICHIER_NUL);
            }

            $ligne_actuel = false;
            $utilisateur_valide = false;
            $indice_ligne = -1;

            // Regarde si l'utilisateur se situe bien dans le fichier et enregistre sa position
            while(!feof($flux))
            {
                $ligne_actuel = fgetcsv($flux, null, ";");
                $indice_ligne++;

                if($ligne_actuel !== false && $ligne_actuel[0] == $id)
                {
                    $utilisateur_valide = true;
                    break;
                } 
            }

            if($utilisateur_valide)
            {
                // Ecrit le fichier sous forme de tableau et suprimme la ligne
                $tableau_utilisateur = file($loca_fichier);
                unset($tableau_utilisateur[$indice_ligne]);

                // Réecris le fichier
                file_put_contents($loca_fichier, $tableau_utilisateur);
                fclose($flux);
                return true;
            }

            fclose($flux);
            return false;
        }

        // Fontion qui deplace une image dans le dossier destination et enregistre le chemin vers dossier ou elle se situera
        function conversion_PP($lien_pp, $destination, $pseudo)
        {
            if(!(file_exists($lien_pp) && is_dir($destination)))
            {
                return message_erreur("LA PHOTO OU LA DESTINATION N'ÉXISTE PAS, VEUILLEZ RENTRER UN LIEN VALIDE");
            }

            // Récupère l'extension de la photo
            $extension = pathinfo($lien_pp)['extension'];
            $nouvel_position = $destination."/".$pseudo.".".$extension;

            // Deplace la photo vers le chemin absolue du nouveau dossier
            rename($lien_pp, $nouvel_position);
            
            return rongnerROOT($nouvel_position);
        }

        // Fonction qui retourne le chemin absolue vers une photo DIY
        function retournerCheminABS_Photo($id, $flux, $indice_cheminCSV)
        {
            if(!$flux)
            {
                message_erreur(FICHIER_NUL);  
            }
    
            $ligne_actuel = recupererInfo_CSV($flux, $id);
            if($ligne_actuel !== false)
            {
                return ROOT.$ligne_actuel[$indice_cheminCSV];
            }
    
            return "";
        }

        function supprimerPhoto($loca_fichier)
        {
            if(is_dir($loca_fichier))
            {
                unlink($loca_fichier);
                return true;
            }

            return false;
        }
        /* Fonction permettant de rajouter une indication par rapport à un "parent" (Ça peut être un commentaire ou une explication d'un DIY)
        Elle écrit dans un fichier ciblée les information ci joint:
            - id_parent: ID du parent
            - nom: Nom du posteur de l'indication
            - valeur: Valeur de l'indication
            - loca_fichier: La position ou les informations doivent être retenu à l'instar de 'utilisateur.txt'
            - loca_BBD: La position ou le fichier contenant la valeur du commentaire doit'être crée
        Elle retourne un tableau où:
            array[0] = Valeur de reussite de la fonction
            array[1] = Chemin absolue du fichier indication
        */
        function ajouterIndication($valeur, $id_indication, $loca_BBD)
        {
            // Creer le fichier contenant la valeur de l'explication
            if(!definirIndication($loca_BBD, $id_indication, $valeur))
            {
                message_erreur("PROBLEME LORS DE L'AJOUT DU FICHIER INDICATION");
            }

            return array(true, $loca_BBD.$id_indication);
        }


        
        // Crée un fichier permettant d'enregister la valeur d'une indication, où le fichier porte le nom de l'id de l'explication
        function definirIndication($loca_BBD, $id_indication, $valeur)
        {
            if(!is_dir($loca_BBD))
            {
                message_erreur("LE FICHIER BBD, N'EXISTE PAS !");
            }

            $flux = fopen($loca_BBD.$id_indication, "w");
            if(!$flux)
            {
                message_erreur("ERREUR LORS DE LA CRÉATION DU FICHIER INDICATION");
            }

            fwrite($flux, $valeur);
            fclose($flux);
            return true;
        }


        /* Cette fonction supprime le fichier retenant l'indication, à appeler à chaque fois que l'on supprime
        une ligne du fichier CSV commentaire */
        function supprimmer_indication($loca_fichier)
        {
            if(file_exists($loca_fichier))
            {
                return unlink($loca_fichier);
            }

            return false;
        }

        // Fonction permettant de retourner la valeur d'un commentaire sous forme de chaine de charactère
        function recuperer_valeur_indication($loca_indication)
        {
            if(!file_exists($loca_indication))
            {
                message_erreur("LE PARAMETRE 'loca_indication' est vide (== ''");
            }
            $flux = fopen($loca_indication, "r+");
            if(!$flux)
            {
                message_erreur(FICHIER_NUL);
            }

            fclose($flux);
            return file_get_contents($loca_indication);
        }


        /* Supprime le parent d'une indication
        $indice_indication: L'indice au quel se trouve le chemin vers l'indication */
        function supprimmerParentIndication($loca_fichier, $id, $indice_indication)
        {
            // On ouvre le fichier cible
            $flux = fopen($loca_fichier, "r+");
            if(!$flux)
            {
                message_erreur(FICHIER_NUL);
            }
    
            $cible = recupererInfo_CSV($flux, $id);
            fclose($flux);
    
            if(!$cible)
            {
                return false;
            }
            
            // Supprime la ligne contentant le commentaire et son fichier
            supprimerLigne_CVS($loca_fichier, $cible[0]);
            supprimmer_indication(ROOT.$cible[$indice_indication]);
    
            return true;
        }

        /** Retourne la ligne contenant l'id ciblié à l'instar de recupererInfoCSV mais ici on deplace le pointeur du fichier à la fin de la ligne retourné
         * @return mixed La valeur de la ligne
         */ 
        function deplacerPointeurversInfo($flux, $id)
        {
            if(!$flux)
            {
                message_erreur(FICHIER_NUL);
            }

            // On s'assure que l'on se situe au début du fichier
            fseek($flux, 0, SEEK_SET);

            $ligne_actuel = false;
            while(!feof($flux))
            {
                $ligne_actuel = fgetcsv($flux, null, ";");
    
                if($ligne_actuel !== false && $ligne_actuel[0] == $id)
                {
                    break;
                }
            }

            return $ligne_actuel;
        }

        /** Retourne un tableau de tout les objets non verifié
         * @param int $indice_verification L'indice ou se trouve la verification
         * @return array Retourne le tableau de DIY
         */
        function Retourner_NonVerifie($loca_fichier, $indice_verification)
        {
            $flux = fopen($loca_fichier, "r+");
            if(!$flux)
            {
                message_erreur(FICHIER_NUL);
            }

            $ligne_actuel = false;
            $collection = array();

            while(!feof($flux))
            {
                $ligne_actuel = fgetcsv($flux, null, ";");
                if($ligne_actuel !== false && $ligne_actuel[$indice_verification] == 0)
                {
                    array_push($collection, $ligne_actuel);
                }
            }

            return $collection;
        }

        /** Fonction permetant de valider une ligne CSV
         * @param mixed $nouvel_valeur 0: Pas verifié 1: Verifié
         * @param mixed $decalage le decalage du pointeur afin d'arrive à la position du charactère à modifier
         */
        function Basculer_ValiditeLigneCSV($loca_fichier, $id, $nouvel_valeur, $decalage)
        {
            $flux = fopen($loca_fichier, "r+");
            if(!$flux)
            {
                message_erreur(FICHIER_NUL);
            }

            $ligne_actuel = deplacerPointeurversInfo($flux, $id);
            if(!$ligne_actuel)
            {
                fclose($flux);
                return false;
            }

            // Securise la valeur pour qu'elle soit entre 0 et 1
            $fichier_fini = feof($flux);
            $nouvel_valeur = clamp($nouvel_valeur, 0, 1);

            // On deplace le pointeur de n charactères vers la droite pour être sur l'ancienne valeur de verification
            fseek($flux, -abs($decalage) + $fichier_fini, SEEK_CUR);
            fwrite($flux, $nouvel_valeur);
            
            fclose($flux);
            return true;
        }
    }
?>
