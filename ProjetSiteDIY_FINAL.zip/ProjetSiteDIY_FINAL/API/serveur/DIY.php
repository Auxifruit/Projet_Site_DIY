<?php

    include_once __DIR__."/master.php";
    include_once __DIR__."/commentaire.php";

    function ouvrire_DIY()
    {
        return fopen(LOCA_DIY, "r+");
    }

    // Ajoute un DIY dans la base de donnée associé
    function ajouter_DIY($nom, $pseudo, $duree, $difficulte, $lienPhoto, $recette)
    {
        $flux = ouvrire_DIY();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        fseek($flux, 0, SEEK_END);

        // Ajoute la photo du DIY
        $DIY_id = uniqid();

        // Enregistre la explication du DIY
        $explication = ajouterIndication($recette, $DIY_id, LOCA_EXP_BDD);
        if(!$explication[0])
        {
            message_erreur("ECHEC LORS DE L'AJOUT DE L'EXPLICATION");
        }
        

        $photo_verif = conversion_PP($lienPhoto, LOCA_PDIY, $DIY_id);
        if(!$photo_verif)
        {
            message_erreur("ECHEC LORS DE L'AJOUT PHOTO->NULL");
        }

        // Enregistre l'id de l'explication
        fputcsv($flux, [$DIY_id, $nom, $pseudo, $duree, $difficulte, $photo_verif, rongnerROOT($explication[1]), "0", "000"], ";");
        fclose($flux);

        // Retourne l'id du DIY ainsi que que le chemin absolue de l'explication
        return array(true, $DIY_id, $explication[1]);
    }

    // S'occupe de rajouter un commentaire dans la base de donner et de recalculer la moyenne du DIY parent
    function ajouter_Commentaire($id_parent, $pseudo, $valeur, $note)
    {
        if(!id_valide(LOCA_DIY, $id_parent))
        {
            message_erreur("L'ID DU DIY EST INVALIDE");
        }

        $resultat = definir_commentaire($id_parent, $pseudo, $valeur, $note);
        modifier_MoyenneDIY($id_parent);
        return $resultat;
    }


    // Retourne le chemin vers la photo de profile
    function recupererCheminABS_PPDIY($id)
    {
        $flux = ouvrire_DIY();
        $chemin = retournerCheminABS_Photo($id, $flux, 5);
        fclose($flux);

        if(is_file($chemin))
        {
            return array(true, $chemin);
        }
        return array(false, '');
    }


    /* Cette fonction retourne un tableau de commentaire en fonction de l'ID d'un DIY
        - array[0]: Le triomphe de la fonction
        - array[1][i][1]: Pseudo du posteur
        - array[1][i][2]: La note attribué au commentaire
        - array[1][i][3]: Chaine de charactere representant la valeur du commentaire
    */
    function retourner_Commentaires($id_DIY)
    {

        $flux = ouvrir_commentaire();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        $tableau_commentaire = array();
        $ligne_actuel = false;
        $valeur_com = false;

        while(!feof($flux))
        {
            $ligne_actuel = fgetcsv($flux, null, ";");
            if($ligne_actuel === false)
            {
                continue;
            }
            // On regarde si le commentaire à comme 'id_parent' le même que 'id_DIY'
            if($ligne_actuel[1] != $id_DIY)
            {
                continue;
            }

            // On ouvre le fichier contenant la valeur du commentaire
            if(!file_exists(ROOT.$ligne_actuel[3])){continue;}
            $valeur_com = recuperer_valeur_indication(ROOT.$ligne_actuel[3]);
            // On ajoute au tableau de commentaire le commentaire et ses information associé
            array_push($tableau_commentaire, array($ligne_actuel[2], $ligne_actuel[4], $valeur_com));
        }

        fclose($flux);
        return array(true, $tableau_commentaire);
    }



    // Fonction qui retourne tout les id des DIYs
    function retourner_idDIY()
    {
        $flux = ouvrire_DIY();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        $id_DIYs = array();
        $ligne_actuel = false;

        while(!feof($flux))
        {
            $ligne_actuel = fgetcsv($flux, null, ";");

            // On verifie que la ligne existe bien et que sont ID n'est pas vide
            if($ligne_actuel !== false && $ligne_actuel[0] != "")
            {
                array_push($id_DIYs, $ligne_actuel[0]);
            }
        }
        
        fclose($flux);
        return $id_DIYs;
    }

    /* Fonction retournant toutes les info d'un DIY
    Elle retourne false si la ligne est invalide */
    function retourner_InfoDIY($idDIY)
    {
        $flux = ouvrire_DIY();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        // Si l'id n'existe pas nous quittons le fichier
        $ligne_actuel = recupererInfo_CSV($flux, $idDIY);
        fclose($flux);

        return $ligne_actuel;
    }

    // Cette fonction recupere le chemin vers l'indication d'un construction d'un DIY
    function recupererIndicationDIY($id)
    {
        $flux = ouvrire_DIY();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        $ligne_actuel = recupererInfo_CSV($flux, $id);
        fclose($flux);

        if(!$ligne_actuel)
        {
            return "";
        }
        
        return recuperer_valeur_indication(ROOT.$ligne_actuel[6]);
    }

    // Fonction retournant un tableau de tout les DIY posté par l'utilisteur
    function retourner_DIYUtilisateur($pseudo)
    {
        $flux = ouvrire_DIY();
        if(!$flux)
        {
            message_erreur($flux);
        }

        $collection_DIY = array();
        $ligne_actuel = false;

        while(!feof($flux))
        {
            $ligne_actuel = fgetcsv($flux, null, ";");
            if($ligne_actuel && $ligne_actuel[2] == $pseudo)
            {
                array_push($collection_DIY, $ligne_actuel);
            }
        }

        return $collection_DIY;
    }


    // Fonction calculant la moyenne d'un DIY et la retournant sous forme d'un tableau de 4 charactères
    function calculer_MoyenneDIY($idDIY)
    {
        $IDs = tableau_IDCommentaire($idDIY, true);
        if(sizeof($IDs) <= 0)
        {
            return array(0,".", 0);
        }

        $nb_IDs = sizeof($IDs);
        $moyenne = 0;
        foreach($IDs as $ID)
        {
            $moyenne += note_commentaire($ID);
        }

        // Calcule de la moyenne en la clampant c'est à dire la mettant entre 0 et 5
        $moyenne = clamp(round($moyenne / $nb_IDs, 1), 0, 5);
        $string_moyenne = str_split(strval($moyenne));
        return $string_moyenne;
    }

    // Fonction modifiant la valeur de la moyenne d'un DIY
    function modifier_MoyenneDIY($id_DIY)
    {
        // On ouvre le flux pour pouvoir reecrire dedans
        $flux = ouvrire_DIY();
        if(!$flux)
        {
            // Si le flux n'est pas valide nous perdons malheureusement le DIY
            message_erreur(FICHIER_NUL."ATTENTION LE DIY: ".$id_DIY." À été supprimé, veuillez le reentrer pour éviter toute perte de données");
        }

        $ligne_actuel = deplacerPointeurversInfo($flux, $id_DIY);

        if(!$ligne_actuel)
        {
            fclose($flux);
            return false;
        }        
        
        
        // Calcul la moyenne
        $moyenne = calculer_MoyenneDIY($id_DIY);
        // On se deplace de 3 charactère et on y écrit la nouvelle moyenne
        fseek($flux, -4 + feof($flux), SEEK_CUR);
        
        // On écrit à la position du pointeur
        
        fwrite($flux, implode("", $moyenne));
        fclose($flux);

        return true;

    }

    // Supprime un commentaire et recalcul la moyenne du DIY
    function supprimerCommentaire($id_commentaire)
    {
        if(!id_valide(LOCA_COMMENTAIRE, $id_commentaire)) {return false;}

        $id_parent = retournerID_Parent($id_commentaire);
        enleverCommentaire($id_commentaire);

        if($id_parent)
        {
            modifier_MoyenneDIY($id_parent);
        }

        return true;
    }

    // Supprime un DIY son explication ainsi que tout ces commentaires associés
    function supprimerDIY($id_DIY)
    {
        $ligne_cible = retourner_InfoDIY($id_DIY);

        if(!$ligne_cible)
        {
            return false;
        }

        // Supprime tout les commentaires associé au DIY
        $tableau_com = tableau_IDCommentaire($id_DIY, false);

        // On supprime la photo du DIY
        supprimerPhoto(ROOT.$ligne_cible[5]);
      
        // Suppression de la ligne du DIY ainsi que son explication
        supprimmerParentIndication(LOCA_DIY, $id_DIY, 6);

        // Supression de tous ses commentaires
        array_map('enleverCommentaire', $tableau_com);

        return true;
    }


    /** Fonction servant à modifier la valeur de verification d'un DIY
     * @param mixed $nouvel_valeur 0: Pas verifié 1: Verifié
     */
    function Basculer_ValiditeDIY($id_DIY, $nouvel_valeur)
    {
        return Basculer_ValiditeLigneCSV(LOCA_DIY, $id_DIY, $nouvel_valeur, 6);
    }

    /** Fonction servant à modifier la valeur de verification d'un DIY
    * @param mixed $nouvel_valeur 0: Pas verifié 1: Verifié
    */
    function Basucler_ValiditeCommentaire($id_commentaire, $nouvel_valeur)
    {
        $succes = Basculer_ValiditeLigneCSV(LOCA_COMMENTAIRE, $id_commentaire, $nouvel_valeur, 2);
        if($succes)
        {
            modifier_MoyenneDIY(retournerID_Parent($id_commentaire));
        }

        return $succes;
    }
    // Retourne tout les DIY non verifé
    function DIY_nonVerifie()
    {
        return Retourner_NonVerifie(LOCA_DIY, 7);
    }

?>