<?php
    include_once __DIR__."/master.php";

    function ouvrir_commentaire()
    {
        return fopen(LOCA_COMMENTAIRE, "r+"); 
    }

    // Fonction rajoutant un commentaitre dans la base de donné sans changer laz moeynne du DIY parent
    function definir_commentaire($id_parent, $pseudo, $valeur, $note)
    {
        $flux = ouvrir_commentaire();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        fseek($flux, 0, SEEK_END);
        $id_commentaire = uniqid();
        $commentaire = ajouterIndication($valeur, $id_commentaire, LOCA_COM_BDD);

        if(!$commentaire[0])
        {
            message_erreur("ERREUR LORS DE L'AJOUT DU COMMENTAIRE");
        }

        fputcsv($flux, [$id_commentaire, $id_parent, $pseudo, rongnerROOT($commentaire[1]), $note, 0], ";");
        fclose($flux);

        // Retourne l'id du commentaire ainsi que le chemin absolue du fichier le contenant
        return array(true, $id_commentaire, $commentaire[1]);
    }


    // Fonction qui retourne un tableau de commentaire en fonction de l'id_DIY et de sa validation
    function tableau_de_Commentaire($id_parent, $seulementValide = true)
    {
        $flux = ouvrir_commentaire();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        $tableau_commentaire = array();
        $ligne_actuel = false;

        while(!feof($flux))
        {
            $ligne_actuel = fgetcsv($flux, null, ";");
            if($ligne_actuel !== false && $ligne_actuel[0] != "" && ($ligne_actuel[5] == 1 || !$seulementValide) && $ligne_actuel[1] == $id_parent)
            {
                array_push($tableau_commentaire, $ligne_actuel);
            }
        }
        return $tableau_commentaire;
    }

    // Fonction recupperant la note d'un commentaire en fonction de son id
    function note_commentaire($id_commentaire)
    {
        $flux = ouvrir_commentaire();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        $ligne_actuel = recupererInfo_CSV($flux, $id_commentaire);
        if($ligne_actuel)
        {
            return $ligne_actuel[4];
        }

        // Si on ne retourne pas la note la fonction ne s'est pas bien executé
        return false;
    }

    // Fonction qui retourne un tableau contenant tout les ids de commentaire qu'un utilisateur a posté validé ou non
    function tableu_IDsCommentaireUTILISTEUR($id_utilisateur)
    {
        $flux = ouvrir_commentaire();
        if(!$flux)
         {
            message_erreur(FICHIER_NUL);
         }

         $ligne_actuel = false;
         $tableau_IDs = array();

         while(!feof($flux))
         {
            
            $ligne_actuel = fgetcsv($flux, null, ";");
            if($ligne_actuel !== false && $ligne_actuel[2] == $id_utilisateur)
            {
                array_push($tableau_IDs, $ligne_actuel[0]);
            }
         }

         return $tableau_IDs;
    }

    /** Retourne un tableau de tous les id de commentaire d'un DIY en fonction du comparateur et de sa validité
     *  @param int $comparateur Indice ou la comparaison de faira avant l'ajout du commentaire dans le tableau
     *  @param mixed $seulementValide ne rajoute le DIY que s'il est valide
     * */

    function retourner_IDCommentaires($id_parent, $comparateur, $seulementValide = true)
    {
        $flux = ouvrir_commentaire();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        $ligne_actuel = false;
        $tableau_IDs = array();

        while(!feof($flux))
        {
            $ligne_actuel = fgetcsv($flux, null, ";");

            // Rajoute l'id dans le tableau si la ligne actuel n'est pas vide
            if($ligne_actuel !== false && $ligne_actuel[0] != "" && ($ligne_actuel[5] == 1 || !$seulementValide) && $ligne_actuel[$comparateur] == $id_parent)
            {
                array_push($tableau_IDs, $ligne_actuel[0]);
            }            
        }
        
        fclose($flux);
        return $tableau_IDs;
    }

    // Fonction retournant l'id du DIY parent d'un commentaire
    function retournerID_Parent($id_commentaire)
    {
        $flux = ouvrir_commentaire();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        $id_parent = recupererInfo_CSV($flux, $id_commentaire)[1];
        fclose($flux);
        return $id_parent;
    }

    // Retourne la valeur d'un commentaire en fonction de son Id
    function retourner_Commentaire($id_commentaire)
    {
        $flux = ouvrir_commentaire();
        if(!$flux)
        {
            message_erreur(FICHIER_NUL);
        }

        $commentaire = recupererInfo_CSV($flux, $id_commentaire);
        if(!$commentaire)
        {
            return "Commentaire Invalide !";
        }

        return recuperer_valeur_indication(ROOT.$commentaire[3]);
    }

    /** Fonction qui retourne un tableau comportant tout les id des commentaire d'un DIY
     * @param bool $seulementValide ne rajoute le DIY que s'il est valide
    */
    function tableau_IDCommentaire($id_parent, $seulementValide = true)
    {
        return retourner_IDCommentaires($id_parent, 1, $seulementValide);
    }
    
    // Fonction uqi retourne un tableau comportant tout les id des commentaire d'un utilisateur
    function tableau_CommentaireUTILISATEUR($id_utilisateur)
    {
        //return retourner_ID($id_utilisateur, 3);
    }

    /* Supprime un commentaire en fonction de son id ainsi que son fichier associé
    À noter que cette fonction ne recalcule pas la moyenne d'un DIY voir supprimer commentaire DIY.php */
    function enleverCommentaire($id_commentaire)
    {
        return supprimmerParentIndication(LOCA_COMMENTAIRE, $id_commentaire, 3);
    }

    // Retourne un tableau avec tout les commentaires non verifié
    function commentaire_nonVerifie()
    {
        return Retourner_NonVerifie(LOCA_COMMENTAIRE, 5);
    }
    
?>
