<?php
    include_once __DIR__."/lib/VariableGlobal.php";
    include_once __DIR__."/lib/TimeoutUtilisateur.php";
    include_once __DIR__."/serveur/utilisateurs.php";

    define("MESSAGE_MAUVAIS_LOGIN", "Le nom d'utilisateur ou mot de passe est incorrect");

    if(isset($_POST["id"]) && isset($_POST["mdp"])){
        $id  = $_POST["id"];  //Enregistre l'identifiant utilisateur
        $mdp = $_POST["mdp"]; //Enregistre le mot de passe utilisateur
        $data=array(
            "ConnexionReussie" => false,
            "MessageErreur" => "",
        );

        //Vérification de l'utilisateur existe dans la base donnée && MDP identique
        if(!est_inscrit($id) || !mdp_identique($id, $mdp)){
            $data["MessageErreur"]=MESSAGE_MAUVAIS_LOGIN;
            echo json_encode($data);
            exit(); //Necessaire pour la redirection immédiate
        }

        //On enregistre le nom d'utilisateur et le timeout
        session_start();
        $_SESSION["utilisateur"]=$id;
        miseAJourTimeout();


        //Redirection vers la page d'acceuil
        $data["ConnexionReussie"]=true;
        echo json_encode($data);
    }
?>