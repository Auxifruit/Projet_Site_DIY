<?php
    include_once __DIR__."/lib/DIYUtils.php";
    include_once __DIR__."/lib/UtilisateurUtils.php";

    define("ERREUR_NOM_DIY", "Le nom du DIY comporte un ou plusieurs problème(s).");
    define("ERREUR_TEMPS_DIY", "Le temps du DIY comporte un ou plusieurs problème(s).");
    define("ERREUR_DIFFICULTE_DIY", "La difficulté du DIY comporte un ou plusieurs problème(s).");
    define("ERREUR_INSTRUCTION_DIY", "Les instructions du DIY comporte un ou plusieurs problème(s).");
    define("ERREUR_IMAGE_DIY", "L'image du DIY comporte un ou plusieurs problème(s).");
    define("ERREUR_INCONNUE", "Une erreur inconnue est survenue, merci de réessayer plus tard.");
    define("NON_CONNECTE", "Veuillez vérifier que vous êtes bien connecté.");

    $nomDIY = $_POST["nom"];
    $tempsDIY = $_POST["duree"];
    $difficulteDIY = $_POST["difficulte"];
    $instructionDIY = $_POST["recette"];
    $cheminImageDIY = TMP_FOLDER."/".uniqid().$_FILES['photo']['name']; //Chemin temporaire

    $extensionImage =  strtolower(pathinfo($cheminImageDIY,PATHINFO_EXTENSION));

    $data = array(
        "AjoutReussie" => false,
        "MessageErreur" => [],
    );
    header("Content-Type: application/json");

    if(!estConnecte()){
        ajoutErreur(NON_CONNECTE, $data);
    }

    if($nomDIY == "" || strpos($nomDIY, ';') !== false || strpos($nomDIY, '\n') !== false){
        ajoutErreur(ERREUR_NOM_DIY, $data);
    }

    if($tempsDIY == "" || !is_numeric($tempsDIY) || strpos($tempsDIY, '\n') !== false){
        ajoutErreur(ERREUR_TEMPS_DIY, $data);
    }

    if($difficulteDIY == "" || !is_numeric($difficulteDIY) || NB_MAX_DIFFICULTE < $difficulteDIY || strpos($difficulteDIY, '\n') !== false){        
        ajoutErreur(ERREUR_DIFFICULTE_DIY, $data);
    }

    if($instructionDIY == "" || strpos($instructionDIY, ';') !== false || strpos($instructionDIY, '\n') !== false){
        ajoutErreur(ERREUR_INSTRUCTION_DIY, $data);
    }

    if(!isset($_FILES['photo']) || move_uploaded_file($_FILES['photo']['tmp_name'], $cheminImageDIY) == false || ($extensionImage != "jpg" && $extensionImage != "png" && $extensionImage != "jpeg" && $extensionImage != "gif")){
        ajoutErreur(ERREUR_IMAGE_DIY, $data);
    }

    if(count($data["MessageErreur"]) != 0){
        echo json_encode($data);
        exit(); //Necessaire pour la redirection immédiate
    }

    $result = ajoutDIY($nomDIY, $tempsDIY, $difficulteDIY, $cheminImageDIY, $instructionDIY);

    if($result == false){
        ajoutErreur(ERREUR_INCONNUE, $data);
        echo json_encode($data);
        exit(); //Necessaire pour la redirection immédiate
    }

    $data["AjoutReussie"]=true;
    echo json_encode($data);


    function ajoutErreur($msg, &$data){
        array_push($data["MessageErreur"], $msg);
    }

    
?>
