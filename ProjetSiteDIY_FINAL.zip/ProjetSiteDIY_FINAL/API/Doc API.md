# Doc du site DIY

Vous trouverez ici la liste des requêtes possible, ainsi que les fonction pour intéragire avec le serveur.
Pour les fichiers PHP la syntaxe est la suivante:

- **PARAM type $nomVariable** : description de la variable
- **RETURN type** : description de la valeur de retourAvec **PARAM** pour un paramètre, **RETURN** pour la valeur de retour, $nomVariable le nom d'une variable, type un/plusieur type, séparé par |
  Exemple:

  ```
  string      : une chaine de caractère
  int|false   : un entier ou la valeur false
  int|boolean : un entier ou un booléen (true/false)
  ```
- [Doc du site DIY](#doc-du-site-diy)
- [API du site DIY](#api-du-site-diy)

  - [Connexion](#connexion)
  - [Déconnexion](#déconnexion)
  - [Inscription](#inscription)
- [Fonction fichier API/recetteSemaine.php](#fonction-fichier-apirecettesemainephp)

  - [getNomDIYSemaine()](#getnomdiysemaine)
  - [getNoteDIYSemaine()](#getnotediysemaine)
  - [getTempsPrépaDIYSemaine()](#gettempsprépadiysemaine)
  - [getPrixDIYSemaine()](#getprixdiysemaine)
  - [getCheminImageDIYSemaine()](#getcheminimagediysemaine)
  - [getCheminDIYSemaine()](#getchemindiysemaine)
- [Fonction fichier /API/DIYUtils.php](#fonction-fichier-apidiyutilsphp)

  - [ajoutDIY(\$nom, \$duree, \$difficulte, \$cheminPhoto, \$explicaiton)](#ajoutdiynom-duree-difficulte-cheminphoto-explicaiton)
  - [rechercheSimpleDIY($nom)](#recherchesimplediynom)
  - [getInfoDIY($idDIY)](#getinfodiyiddiy)
  - [getCommentairesDIY($idDIY)](#getcommentairesdiyiddiy)
  - [getRandomCommentaireDIY($idDIY)](#getrandomcommentairediyiddiy)
- [Fonction fichier API/UtilisateurUtils.php](#fonction-fichier-apiutilisateurutilsphp)

  - [estConnecte()](#estconnecte)
  - [estAdmin()](#estadmin)
  - [getNomUtilisateur()](#getnomutilisateur)
  - [getURLImageProfile($nomUtilisateur=null)](#geturlimageprofilenomutilisateurnull)
  - [getNombreDIYUtilisateur($nomUtilisateur=null)](#getnombrediyutilisateurnomutilisateurnull)
  - [getNombreCommentaireUtilisateur($nomUtilisateur=null)](#getnombrecommentaireutilisateurnomutilisateurnull)

# API du site DIY

L'API permet d'intéragire avec le serveur a l'aide de requêtes POST et GET. La réponse seras toujours envoyé au format JSON

## Ajout DIY

  -**URL** : /API/ajoutDIY.php
  -**METHODE** : POST
  -**CHAMPS** :

```
nom: le nom d'utilisateur
temps: le temps de préparation (int/float)
difficulte: le niveau de difficulté (entre 1 et 5)
instruction: les instruction du DIY
image: l'image du DIY
```

  -**REPONSE** : Format JSON

```
{
AjoutReussie: Si la connexion est réussit (true/false)
MessageErreur: le(s) message(s) d'erreur(s) associé(s)
}
```

## Connexion

  -**URL** : /API/connexion.php
  -**METHODE** : POST
  -**CHAMPS** :

```
id: le nom d'utilisateur
mdp: le mot de passe

Exemple:
  id=theo&mdp=guigui
```

  -**REPONSE** : Format JSON, penser à récupèrer le cookie PHP_SESSION

```
{
ConnexionReussie: Si la connexion est réussit (true/false)
MessageErreur: le message d'erreur associé
}
```

## Déconnexion

  -**URL** : /API/deconnexion.php
  -**METHODE** : GET
  -**REPONSE** : pas de réponse, redirige tout simplement vers la page d'accueil

## Inscription

  -**URL** : /API/inscription.php
  -**METHODE** : POST
  -**CHAMPS** :

```
id: le nom d'utilisateur
mdp: le mot de passe

Exemple:
  id=theo&mdp=guigui
```

  -**REPONSE** :

```
InscriptionReussie: Si la connexion est réussit (true/false)
MessageErreur: le message d'erreur associé
```

## Mise a jour photo de profil utilisateur

  -**URL** : /API/MajImageUtilisateur.php
  -**METHODE** : POST
  -**CHAMPS** :

```
image: la nouvel image utilisateur
```

  -**REPONSE** :

```
ChangementReussi: Si l'image a bien été changé
MessageErreur: le(s) message(s) d'erreur(s) associé(s)
```

&nbsp;
&nbsp;

# Fonction fichier API/recetteSemaine.php

Ce fichier php contient toute les fonctions permetants de récupèrer les informations relatives au DIY de la semaine

## getNomDIYSemaine()

-**RETURN** String: le nom du DIY de la semaine

## getNoteDIYSemaine()

-**RETURN** String : la note du DIY de la semaine

## getTempsPrépaDIYSemaine()

-**RETURN** String : le temps de préparation du DIY de la semaine

## getPrixDIYSemaine()

-**RETURN** String : le prix du DIY de la semaine

## getCheminImageDIYSemaine()

-**RETURN** String : le chemin de l'image du DIY de la semaine

## getCheminDIYSemaine()

-**RETURN** String : le chemin du DIY de la semaine

&nbsp;
&nbsp;

# Fonction fichier /API/DIYUtils.php

Ce fichier PHP contient les fonctions pour gérer les DIY

## ajoutDIY(\$nom, \$duree, \$difficulte, \$cheminPhoto, \$explicaiton)

Fonction qui ajoute un DIY dans la base de donnée. Par défaut, le créateur du DIY est l'utilisateur courrament connecté

- **PARAM string $nom** : le nom du DIY
- **PARAM int $duree** : le temps de fabrication du DIY
- **PARAM int $difficulte** : la difficulte entre 0 et NB_MAX_DIFFICULTE
- **PARAM string $cheminPhoto** : le chemin de la photo du DIY sur le serveur
- **PARAM string $explicaiton** : les exlications du DIY
- **RETURN array** : un tableau avec :

  - [0] : true, pour dire que la fonctoin c'est bien passé
  - [1] : l'id du commentaire
  - [2] : le chemin absolue du fichier d'instruction du DIY sur le serveur

## rechercheSimpleDIY($nom)

Fonction qui permet de faire une recherche simple dans la base de donnée

- **PARAM string $nom** : La chaine de recherche spécifié par l'utilisateur\
- **RETURN array** : un chaine de dimension 2, plusieur ligne trié dans l'ordre croissant de poximité de la recherche. Les valeurs de chaques colones sont:
  - [0] : La proximité avec le DIY
  - [1] : La proximité maximmal avec le DIY pour que le résultat soit gardé
  - [2] : l'id du DIY
  - [3] : le nom du DIY
  - [4] : le créateur du DIY
  - [5] : le temps de préparation du DIY
  - [6] : la difficulté du DIY
  - [7] : le chemin de la photo du DIY
  - [8] : les explications du DIY
  - [9] : La notes du DIY

## getInfoDIY($idDIY)

Renvoie les infos d'un DIY

- **PARAM string $idDIY** : l'id du DIY
- **RETURN array|false** : un tableau avec les infos des DIY, si renvoie false, l'id n'existe pas
  - [0] : l'id du DIY
  - [1] : le nom du DIY
  - [2] : le créateur du DIY
  - [3] : le temps de préparation du DIY
  - [4] : la difficulté du DIY
  - [5] : le chemin de la photo du DIY
  - [6] : les explications du DIY
  - [7] : La notes du DIY

## getCommentairesDIY($idDIY)

Fonction qui permet de récupèrer les commentaires pour un DIY donnée

- **PARAM string $idDIY** : l'id de DIY
- **RETURN array|bool** : un tableau de dimension 2, pour chaque commentaire il y a à l'emplacement :
  - [0] : le nom du commentateur
  - [1] : son image de profile
  - [2] : la note qu'il a donné au DIY
  - [3] : le contenu du commentaire

## getRandomCommentaireDIY($idDIY)

Fonction qui permet de récupèrer un commentaire aléatoire pour un DIY donnée

- **PARAM string $idDIY** : l'id de DIY
- **RETURN array|bool** : un tableau de dimension 1, il y a à l'emplacement :
  - [0] : le nom du commentateur
  - [1] : son image de profile
  - [2] : la note qu'il a donné au DIY
  - [3] : le contenu du commentaire

## getToutIdDIY()

Fonction qui permet de récupèrer les ids de tous les DIY
**RETURN array** : une list contenant les ids de tous les DIY

## suppCommentaire($idCommentaire)

Fonction qui permet de supprimer un commentaire, renvoi notamment false si l'utilisateur connecté n'est pas admin/l'utilisateur qui la posté
**PARAM string $idCommentaire** : l'id du commentaire
**RETURN boolean** : si la suppresion a réussit (true) ou non (false)

## suppDIY()

Fonction qui permet de supprimer un DIY, renvoi notamment false si l'utilisateur connecté n'est pas admin/l'utilisateur qui la posté
**PARAM string $idDIY** : l'ID du DIY a supprimer
**RETURN boolean** : si la suppression a réussit (true) ou non (false)

## getDIYaVerifier()

Fonction qui renvoie les DIYs à vérifier
Necessite d'être connecté en tant qu'administrateur
**RETURN array|int** un tableau a deux dimension contenant :

- [0] : l'id du DIY
- [1] : le nom du DIY
- [2] : le créateur du DIY
- [3] : le temps de préparation du DIY
- [4] : la difficulté du DIY
- [5] : le chemin de la photo du DIY
- [6] : les explications du DIY
- [7] : La notes du DIY

  Ou un message d'erreur :
- -1 : l'utilisateur n'est pas connecté
- -2 : l'utilisateur n'est pas admin

## getCommaVerifier()

Fonction qui renvoie les commentaires à vérifier
Necessite d'être connecté en tant qu'administrateur
**RETURN array|int** un tableau a deux dimension contenant :

- [0] : l'id du commentaire
- [1] : l'id du DIY ou il est posté
- [2] : l'id du redacteur
- [3] : l'URL de l'image du redacteur
- [4] : le contenue
- [5] : la note donnee par le commentateur

  Ou un message d'erreur :
- -1 : l'utilisateur n'est pas connecté
- -2 : l'utilisateur n'est pas admin

## validerDIY($idDIY)

Permet de valider un diy
**PARAM string idDIY** : l'id d'un DIY
**RETURN true|int** : true si tout c'est bien passé, ou un code d'erreur

- -1 : L'utilisateur n'est pas connecté
- -2 : L'utilisateur n'est pas admin
- -3 : Une erreur inconnue avec la base de donnée

## validerCommentaire($idComm)

Permet de valider un commentaire
**PARAM string idDIY** : l'id d'un commentaire
**RETURN true|int** : true si tout c'est bien passé, ou un code d'erreur

- -1 : L'utilisateur n'est pas connecté
- -2 : L'utilisateur n'est pas admin
- -3 : Une erreur inconnue avec la base de donnée

## getDateCreationDIY($idDIY)

Renvoie la date de création du DIY a partir de son ID
**PARAM string $idDIY** : l'id du DIY
**RETURN string** : la date de création du DIY sous form dd/mm/yyyy

## getDateCreationCommentaire($idComm)

Renvoie la date de création d'un commentaire a partir de son ID
**PARAM string $idComm** : l'id du commentaire
**RETURN string** : la date de création du commentaire sous form dd/mm/yyyy

&nbsp;
&nbsp;

# Fonction fichier API/UtilisateurUtils.php

Ce fichier PHP contient les fonctions pour gérer les utilisateurs. Hormis estConnecte() et estAdmin(), l'ensemble des fonction qui intéragissent avec l'utilisateur courant mettent à jour le time out de l'utilisateur.

## estConnecte()

Vérifie si l'utilisateur est connecté

- **RETURN boolean** : renvoie si l'utilisateur est connecté (true) ou non (false)

## estAdmin()

Verifie si l'utilisateur courament/derniereme connecté est admin
**⚠️ ATTENTION**, si l'utilisateur a été déconnecté par time out, la fonction renveras quand même si l'utilisateur est admin

- **PARAM string|null $nomUtilisateur=null** : Le nom de l'utilisateur, si null (par défaut) récupèreras l'utilisateur courament connecté
- **RETURN boolean** : renvoie si l'utilisateur connecté est admin (true) ou non (false). Si personne n'est connecté renvoie false.

## estSuperAdmin()

Verifie si l'utilisateur courament/derniereme connecté est super admin
/!\ ATTENTION, si l'utilisateur a été déconnecté par time out, la fonction renveras quand même si l'utilisateur est admin

- **PARAM string|null $nomUtilisateur=null** : Le nom de l'utilisateur, si null (par défaut) récupèreras l'utilisateur courament connecté
- **RETURN boolean** : renvoie si l'utilisateur connecté est super admin (true) ou non (false). Si personne n'est connecté renvoie false.

## getNomUtilisateur()

Renvoie le nom d'utilisateur connecté

- **RETURN string|false** : le nom de l'utilisateur connecté, renvoie
  false si aucun utilisateur est connecté

## getURLImageProfile($nomUtilisateur=null)

Renvoie L'URL de l'image de profile de l'utilisateur passé en paramètre

- **PARAM string|null $name** : par défaut null, si le nom d'utilisateur vaut null, il récupèreras celuis de l'utilisateur connecté, sinon il prendra celui de l'utilisateur passé en paramètre
- **RETURN string|false** : le chemin de l'image si l'utilisateur existe/est connecté, renvoie false en cas d'erreur.

## getNombreDIYUtilisateur($nomUtilisateur=null)

Renvoie le nombre de DIY créer par l'utilisateur

- **PARAM string|null $nomUtilisateur=null** : l'utilisateur en question, si la variable vaut null, récupère l'utilisateur courrant
- **RETURN int|false** : le nombre de DIY créé par l'utilisateur, renvoie false si aucun utilisateur n'est trouvé/connecté

## getNombreCommentaireUtilisateur($nomUtilisateur=null)

Renvoie le nombre de commentaire créer par l'utilisateur

- **PARAM string|null $nomUtilisateur=null** : l'utilisateur en question, si la variable vaut null, récupère l'utilisateur courrant
- **RETURN int|false** : le nombre de commentaire écrit par l'utilisateur, renvoie false si aucun utilisateur n'est trouvé/connecté

## suppUtilisateur($motDePasse)

Supprime l'utilisateur courrament connecté
Le mot de passe est demandé pour des raisons de sécurité, donc si l'utilisateur est déconnecté par time out, la fonction marcheras quand même
**PARAM string $motDePasse** : le mot de passe de l'utilisateur connecté
**PARAM string $nomUtilisateur=null** : le nom d'utilisateur d'un autre compte si l'utilisateur connecté est admin
**RETURN true|int** renvoie true si l'utilisateur a bien été supprimé, si une erreur est survenue, renvoie un code d'erreur :

- -1 : La session n'existe pas ou à été supprimé
- -2 : L'utilisateur a déjà été supprimer ou n'existe pas
- -3 : Le mot de passe de l'utilisateur n'est pas le bon
- -4 : Une erreur inconue c'est produite à la suppresion
- -5 : Si supression d'un autre compte que le sien, l'utilisateur connecté n'est pas admin

## getToutIdDIY()

Fonction qui permet de récupèrer les ids de tous les DIY

- **RETURN array** : une list contenant les ids de tous les DIY

## rechercheSimpleUtilisateur()

Fonction qui permet de faire une recherche simple dans la base de donnée utilisateur

- **PARAM string $nom** : La chaine de recherche spécifié par l'admin
- **RETURN array** : un chaine de dimension 2, plusieur ligne trié dans l'ordre croissant de poximité de la recherche. Les valeurs de chaques colones sont:
- [0] : La proximité avec le DIY
- [1] : La proximité maximal avec le DIY pour que le résultat soit gardé
- [2] : le nom/id de l'utilisateur
- [3] : le mot de passe hashé
- [4] : le status (0 => utilisateur, 1 => admin)
- [5] : le temps de préparation du DIY
- [6] : l'image de profil

## promouvoirAdmin($nomUtilisateur)

Permet au super admin de promouvoir un utilisateur admin
**PARAM string $nomUtilisateur** : le nom d'utilisateur du nouvel administrateur
**RETURN true|boolean** : Si l'utilisateur spécifié a bien été ajouté en tant qu'admin, ou un code d'erreur

- -1 : utilisateur courrant n'est pas connecté
- -2 : utilisateur courrant n'est pas super admin
- -3 : utilisateur cible n'existe pas
- -4 : utilisateur cible est déjà administrateur
- -5 : utilisateur cible est super administrateur
- -6 : erreur inconnue

## destituer($nomUtilisateur)

Permet au super admin de destituer un admin
**PARAM string $nomUtilisateur** : le nom d'utilisateur de l'ancien administrateur
**RETURN true|boolean** : Si l'utilisateur spécifié bien été supprimé en tant qu'admin, ou un code d'erreur

- -1 : utilisateur courrant n'est pas connecté
- -2 : utilisateur courrant n'est pas super admin
- -3 : utilisateur cible n'existe pas
- -4 : utlisateur cible n'est pas administrateur
- -5 : erreur inconnue

## passationSuperAdmin($nomUtilisateur)

Permet au super admin de passer son status à un autre administrateur
**PARAM string $nomUtilisateur** : le nom d'utilisateur du nouveau super admin
**RETURN true|boolean** : Si l'utilisateur spécifié a bien été désigné comme nouveau super admin, ou un code d'erreur

- -1 : utilisateur courrant n'est pas connecté
- -2 : utilisateur courrant n'est pas super admin
- -3 : utilisateur cible n'existe pas
- -4 : utilisateur cible n'est pas administrateur
- -5 : erreur inconnue
