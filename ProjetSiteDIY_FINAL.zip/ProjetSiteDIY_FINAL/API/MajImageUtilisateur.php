<?php
    include_once __DIR__."/lib/VariableGlobal.php";
    include_once __DIR__."/lib/TimeoutUtilisateur.php";
    include_once __DIR__."/serveur/utilisateurs.php";
    include_once __DIR__.'/lib/UtilisateurUtils.php';

    define("ERREUR_IMAGE", "L'image utilisateur comporte un ou plusieurs problème(s).");
    define("ERREUR_INCONNUE", "Une erreur inconnue est survenue, merci de réessayer plus tard.");
    define("NON_CONNECTE", "Veuillez vérifier que vous êtes bien connecté.");

    $cheminImageDIY = TMP_FOLDER."/".uniqid().$_FILES['n_photo']['name']; //Chemin temporaire
    
    $extensionImage = strtolower(pathinfo($cheminImageDIY,PATHINFO_EXTENSION));

    header("Content-Type: application/json");
    $data = array(
        "AjoutReussie" => false,
        "MessageErreur" => [],
    );

    if(!isset($_FILES['n_photo']) || move_uploaded_file($_FILES['n_photo']['tmp_name'], $cheminImageDIY) == false || ($extensionImage != "jpg" && $extensionImage != "png" && $extensionImage != "jpeg" && $extensionImage != "gif")){
        ajoutErreur(ERREUR_IMAGE, $data);
    }

    
    if(($nomutilisateur = getNomUtilisateur()) == false){
        ajoutErreur(NON_CONNECTE, $data);
    }

    if(count($data["MessageErreur"]) != 0){
        echo json_encode($data);
        exit(); //Necessaire pour la redirection immédiate
    }

    $result = true;
    rename($cheminImageDIY, ROOT.getURLImageProfile());
    if($result == false){
        ajoutErreur(ERREUR_INCONNUE, $data);
        echo json_encode($data);
        exit(); //Necessaire pour la redirection immédiate
    }

    $data["AjoutReussie"] = true;
    echo json_encode($data);

    function ajoutErreur($msg, &$data){
        array_push($data["MessageErreur"], $msg);
    }
?>
