<?php
    include_once __DIR__."/../lib/DIYUtils.php";
    include_once __DIR__."/../lib/Utilisateur.php";

    //print_r(getRandomCommentaireDIY("645e2a21e03e4"));
    print_r(rechercheSimpleUtilisateur("mario"));
?>