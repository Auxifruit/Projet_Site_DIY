<?php
    include_once __DIR__."/../lib/VariableGlobal.php";
    include_once __DIR__."/../lib/DIYUtils.php";
    include_once __DIR__."/../lib/UtilisateurUtils.php";
    include_once __DIR__."/../serveur/utilisateurs.php";
    include_once __DIR__."/../serveur/hebdo.php";

    //Ajout admin
    $tempFileName=uniqid("bowser").".png";
    copy(ROOT."/data/images/bowser.png", ROOT."/tmp/".$tempFileName);
    $result = ajouter_utilisateur("bowser", "bowser", ROOT."/tmp/".$tempFileName);
    echo $result."<br>";
    changerImportance("bowser", 2);

    //Ajout 4 utilisateur
    $tempFileName=uniqid("daisy").".png";
    copy(ROOT."/data/images/daisy.png", ROOT."/tmp/".$tempFileName);
    $result = ajouter_utilisateur("daisy", "daisy", ROOT."/tmp/".$tempFileName);
    echo $result."<br>";

    $tempFileName=uniqid("mario").".png";
    copy(ROOT."/data/images/mario.png", ROOT."/tmp/".$tempFileName);
    $result = ajouter_utilisateur("mario", "mario", ROOT."/tmp/".$tempFileName);
    echo $result."<br>";

    $tempFileName=uniqid("pacman").".png";
    copy(ROOT."/data/images/pacman.png", ROOT."/tmp/".$tempFileName);
    $result = ajouter_utilisateur("pacman", "pacman", ROOT."/tmp/".$tempFileName);
    echo $result."<br>";

    $tempFileName=uniqid("sonic").".png";
    copy(ROOT."/data/images/sonic.png", ROOT."/tmp/".$tempFileName);
    $result = ajouter_utilisateur("sonic", "sonic", ROOT."/tmp/".$tempFileName);
    echo $result."<br>";


    copy(ROOT."/data/images/bolBois.jpg", ROOT."/tmp/bolBois.jpg");
    ajouter_DIY("Bol maison", "daisy", 20, 3, ROOT."/tmp/bolBois.jpg", "Il faut un tronc d'arbre, n’importe quel tronc ne peut servir à fabriquer un bol. Il faut un bois robust et saint pour povoir manger dedans (essence dite alimentaire) comme par exemple du chêne.<br>
Ensuite, a l'aide d'un tour a bois, vous pourrez donnez la forme que vous désirez a votre oeuvre ! Je vous conseil de le faire dans le sens du bois afin de ne pas abimer la fibre.<br>
Ensuite il suffiras de ponser votre bol, de le décorer de gravure ou autre et enfin de le vernir de vernis alimentaire pour le protéger.<br>
Je vous laisse voire le résultat !!!");

    copy(ROOT."/data/images/tableAcier.jpg", ROOT."/tmp/tableAcier.jpg");
    ajouter_DIY("Table basse en acier", "sonic", 80, 5, ROOT."/tmp/tableAcier.jpg", "Pour ce DIY il va vous faloir DU FEUX CHAUD !! En effet on va souder et plier des plaque de métale pour faire cette manifique table basse en acier! <br>
Attention, le feu ça brule, c'est dangereurs, faite donc attention !<br>
Pour se faire, on va découper avec une disqueuse les piedssur la plaque de métal, un fois fais, on va découper la moitier du lien entre notre table et le pied pour pouvoir le plier et faire notre pied.<br>
Il suffiras de souder les pied pour qu'il ne bouge plus, puis si vous le voulez souder une plaque inférieur pour faire une table basse a deux niveau !<br>
Niveau finition, un peux de disque a poncer le métal et de peinture de votre choix seras amplemant suffisant.");

    copy(ROOT."/data/images/casquetteRouge.jpg", ROOT."/tmp/casquetteRouge.jpg");
    ajouter_DIY("Fabrication casquette rouge", "mario", 35, 2, ROOT."/tmp/casquetteRouge.jpg", "Ajourd'hui, on va faire DU ROUGGEEEEE !!! Enfin une casquette rouge quoi<br>
Pour ça il vous faudras un patron de casquette et beaucoup de fil rouge.<br>
Une fois votre forme faite, vous pourrez broder une lettre, comme un M par exemple en rouge sur fond blanc !!!<br>
Le résultat est incroyable, et vous pouvez le faire en vert avec un L comme mon frère la fait pas exemple, ne vous mettez pas de limite.");

    copy(ROOT."/data/images/bambou.jpg", ROOT."/tmp/bambou.jpg");
    ajouter_DIY("Fabricaiton tuyaux en bambooooo", "mario", 5, 1, ROOT."/tmp/bambou.jpg", "Pour se faire on va ACHETER DU BAMBOU, puis les relier avec du scotch étanche, rien de plus simple !");

    copy(ROOT."/data/images/ordi_pacman.png", ROOT."/tmp/ordi_pacman.png");
    ajouter_DIY("Contoure écran design au cuter", "pacman", 35, 4, ROOT."/tmp/ordi_pacman.png", "DIY spécial contoure d'écran design avec un cuter, des tylo indébile et cuter !!<br>
Il vous faudras une plaque de plastique de 1mm d'épaisseur, coupez la au cuter a la taille de votre écran.<br>
Ensuite il faudras dessiner dessus avec vos feutre indélébile. Après le couche de vernis apliqué vous pourez le collez a votre écran pour le rendre unique !");
    
    copy(ROOT."/data/images/coquenoir.jpg", ROOT."/tmp/coquenoir.jpg");
    ajouter_DIY("Coque téléphone custom", "daisy", 15, 1, ROOT."/tmp/coquenoir.jpg", "Voici comment customiser sa coque de téléphone, rien de bien compliqué:<br>
Prenez votre coque de téléphone couleur unis (moi je l'ai prise noire) et a l'aide de stylo indélébile, desiné ce que vous voulez<br>
Une fois fais acheter dans votre supermarché du verni mat ou brillant toute surface et appliquez-en une couche légère sur votre coque afin de protégé vos desin<br>
Voilà c'est terminé, vous pouvez admirer le résultat");

    //DIY BOL
    $stream = ouvrire_DIY();
    $idDIY = recupererInfo_CSV($stream, "Bol maison", 1)[0];
    fclose($stream);
    ajouter_commentaire($idDIY, "bowser", "Pas mal ma petite Daisy, tu m'en feras un pour mon anniv", 5);
    ajouter_commentaire($idDIY, "pacman", "On peut mettre des phantome dedans ?", 4);
    ajouter_commentaire($idDIY, "mario", "Houhou, je vais m'en faire un rouge", 5);

    $stream = ouvrire_DIY();
    $idDIY = recupererInfo_CSV($stream, "Table basse en acier", 1)[0];
    fclose($stream);
    ajouter_commentaire($idDIY, "sonic", "J'aime pas le noir, je préfère le bleu moi !", 2);
    ajouter_commentaire($idDIY, "mario", "Houhou, je vais m'en faire un rouge, mais avant je vais acheter un chalumau rouge", 5);
    ajouter_commentaire($idDIY, "bowser", "Faite attention a ne pas mettre feu a votre maison", 4);
    ajouter_commentaire($idDIY, "daisy", "Ca rend vraiment bien, avec des petits dessins et en vert ca aurrait été parfait, mais c'est trop compliqué pour moi ...", 3);

    $stream = ouvrire_DIY();
    $idDIY = recupererInfo_CSV($stream, "Fabrication casquette rouge", 1)[0];
    fclose($stream);
    ajouter_commentaire($idDIY, "pacman", "Je vais en faire un jaune avec moi dessus !!", 5);
    ajouter_commentaire($idDIY, "bowser", "Simple et très sympa, merci mario", 5);
    ajouter_commentaire($idDIY, "sonic", "La casquette qui donne de la vitesse !", 4);

    ajouter_hebdo();

?>