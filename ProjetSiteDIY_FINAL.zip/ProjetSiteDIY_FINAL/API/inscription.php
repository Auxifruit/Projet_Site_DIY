<?php
    include_once __DIR__."/lib/VariableGlobal.php";
    include_once __DIR__."/lib/TimeoutUtilisateur.php";
    include_once __DIR__."/serveur/utilisateurs.php";

    define("MESSAGE_LOGIN_EXISTE", "Le nom d'utilisateur existe déjà");

    $id  = $_POST["id"];  //Enregistre l'identifiant utilisateur
    $mdp = $_POST["mdp"]; //Enregistre le mot de passe utilisateur
    $data=array(
        "InscriptionReussie" => false,
        "MessageErreur" => "",
    );
    header("Content-Type: application/json");

    $tempFileName=uniqid("photoUser").".png";
    copy(ROOT."/photo.png", ROOT."/tmp/".$tempFileName);
    $result = ajouter_utilisateur($id, $mdp, ROOT."/tmp/".$tempFileName);

    //Si le nom d'utilisateur n'existe pas encore
    if($result == false){
        $data["MessageErreur"]=MESSAGE_LOGIN_EXISTE;
    }else{
        //Inscription de l'utilisateur
        $data["InscriptionReussie"]=true;
    }
    echo json_encode($data);
?>