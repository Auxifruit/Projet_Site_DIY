<?php
if (!defined('URL_ACCEUIL')) {
    define("URL_ACCEUIL", "/");
    define("URL_CONNEXION", "/connexion.php");

    define("NB_MAX_NOTE", 5);
    define("NB_MAX_DIFFICULTE", 5);

    define("ID_UTILISATEUR", "utilisateur");

    //Chemin fichier, et pas URL /!\
    include_once __DIR__."/../serveur/master.php";
    define("TMP_FOLDER", ROOT."/tmp");

    //INDICE COLONE BASE UTILISATEUR
    define("ID_COLONE_NOM_UTILISATEUR", 0);
    define("ID_COLONE_HASH_MDP_UTILISATEUR", 1);
    define("ID_COLONE_EST_ADMIN", 2);
    define("ID_COLONE_IMAGE_UTILISATEUR", 3);

    //INDICE COLONE BASE DIY
    define("ID_COLONE_ID_DIY", 0);
    define("ID_COLONE_NOM_DIY", 1);
    define("ID_COLONE_NOM_CREATEUR", 2);
    define("ID_COLONE_TEMPS_PREPA", 3);
    define("ID_COLONE_DIFFICULTE", 4);
    define("ID_COLONE_PHOTO", 5);
    define("ID_COLONE_EXPLICATION", 6);
    define("ID_COLONE_EST_VERIF", 7);
    define("ID_COLONE_NOTES", 8);
    
    //INDICE COLONE BASE COMMENTAIRE
    define("ID_COLONE_ID_COMMENTAIRE", 0);
    define("ID_COLONE_ID_DIY_COMMENTAIRE", 1);
    define("ID_COLONE_NOM_READACTEUR", 2);
    define("ID_COLONE_CHEMIN_CONTENU", 3);
    define("ID_COLONE_NOTE_COMM", 4);

    function getDateCreation($id){
        return date('d/m/Y', hexdec(substr($id, 0, -5)));
    }
}
?>
