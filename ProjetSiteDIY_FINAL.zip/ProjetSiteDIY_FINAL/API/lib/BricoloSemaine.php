<?php
    include_once __DIR__."/../serveur/hebdo.php";
    include_once __DIR__."/UtilisateurUtils.php";
    include_once __DIR__."/DIYUtils.php";

    function getNomBricolo(){
    	if(recuperer_InfoHebdo() == false){return "";}
        return recuperer_InfoHebdo()[0];
    }
    function getNomDIYBricolo(){
		if(recuperer_InfoHebdo() == false){return "";}
        $diy = dernierDIY(recuperer_InfoHebdo()[0]);
        if($diy == -1){ return "Aucun DIY posté"; }
        return $diy[1];
    }

    function getTempsPrépaDIYBricolo(){
    	if(recuperer_InfoHebdo() == false){return "";}
        $diy = dernierDIY(recuperer_InfoHebdo()[0]);
        if($diy == -1){ return "0"; }
        return $diy[3];
    }

    function getCheminImageDIYBricolo(){
    	if(recuperer_InfoHebdo()[0] == "null"){return "/data/images/noImage.jpg";}
        return getURLImageProfile(recuperer_InfoHebdo()[0]);
    }

    function getCheminDIYBricolo(){
    	if(recuperer_InfoHebdo() == false){return "";}
        $diy = dernierDIY(recuperer_InfoHebdo()[0]);
        if($diy == -1){ return ""; }
        return" DIY_recette.php?Id=".$diy[0];
    }

    function dernierDIY($nomUtilisateur){
        $listeDIY = getDIYUtilisateur($nomUtilisateur);
        if($listeDIY == false){return -1;}
        if(count($listeDIY) == 0){ return -1; }

        $min = 0;
        for($i = 1; $i < count($listeDIY); $i++){
            if(getDateCreationDIY($listeDIY[$i][0]) < getDateCreationDIY($listeDIY[$min][0])){
                $min = $i;
            }
        }

        return $listeDIY[$min];
    }
?>
