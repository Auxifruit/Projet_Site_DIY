<?php   
    include_once __DIR__."/VariableGlobal.php";
    include_once __DIR__."/TimeoutUtilisateur.php";
    include_once ROOT."/API/serveur/utilisateurs.php";  
    include_once ROOT."/API/serveur/DIY.php";
    include_once ROOT."/API/serveur/commentaire.php"; 
    include_once __DIR__."/AlgoRecherche.php";
    
    /**
     * Vérifie si l'utilisateur est connecté
     * @return boolean : renvoie si l'utilisateur est connecté (true) ou non (false)
     */
    function estConnecte(){
        if(session_status() != PHP_SESSION_ACTIVE){
            session_start();
        }

        if(!isset($_SESSION[ID_UTILISATEUR])){
            return false;
        }

        if(estTimeOut()){
            return false;
        }
        miseAJourTimeout();
        return true;

    }

    /**
     * Verifie si l'utilisateur courament/derniereme connecté est admin
     * /!\ ATTENTION, si l'utilisateur a été déconnecté par time out, la fonction renveras quand même si l'utilisateur est admin
     * @param string|null $nomUtilisateur=null : Le nom de l'utilisateur, si null (par défaut) récupèreras l'utilisateur courament connecté
     * @return boolean : renvoie si l'utilisateur connecté est admin (true) ou non (false). Si personne n'est connecté renvoie false.
     */
    function estAdmin($nomUtilisateur=null){
        if(session_status() != PHP_SESSION_ACTIVE){
            session_start();
        }

        if($nomUtilisateur == null){
            /* On ne vérifie pas si il est TimeOut
             * car on ne veut pas savoir si il est connecté & admin
             * mais seulement voir si il l'utilisateur es admin.
             */
            if(!isset($_SESSION[ID_UTILISATEUR])){
                return false;
            }

            $nomUtilisateur = $_SESSION[ID_UTILISATEUR];
        }else{
            if(!est_inscrit($nomUtilisateur)){ return false; }
        }

        
        $resultat = retourner_importance($nomUtilisateur);
        return $resultat == 1 || $resultat == 2 ? true : false;
    }

    /**
     * Verifie si l'utilisateur courament/derniereme connecté est super admin
     * /!\ ATTENTION, si l'utilisateur a été déconnecté par time out, la fonction renveras quand même si l'utilisateur est admin
     * @param string|null $nomUtilisateur=null : Le nom de l'utilisateur, si null (par défaut) récupèreras l'utilisateur courament connecté
     * @return boolean : renvoie si l'utilisateur connecté est super admin (true) ou non (false). Si personne n'est connecté renvoie false.
     */
    function estSuperAdmin($nomUtilisateur=null){
        if($nomUtilisateur == null){
            if(session_status() != PHP_SESSION_ACTIVE){
                session_start();
            }

            /* On ne vérifie pas si il est TimeOut
             * car on ne veut pas savoir si il est connecté & admin
             * mais seulement voir si il l'utilisateur es admin.
             */
            if(!isset($_SESSION[ID_UTILISATEUR])){
                return false;
            }

            $nomUtilisateur = $_SESSION[ID_UTILISATEUR];
        }else{
            if(!est_inscrit($nomUtilisateur)){ return false; }
        }

        return retourner_importance($nomUtilisateur) == 2 ? true : false;
    }

    /**
     * Renvoie le nom d'utilisateur connecté
     * @return string|false : le nom de l'utilisateur connecté, renvoie false si aucun utilisateur est connecté
     */
    function getNomUtilisateur(){
        if(session_status() != PHP_SESSION_ACTIVE){
            session_start();
        }
        
        if(!isset($_SESSION[ID_UTILISATEUR]) || estTimeOut()){
            return false;
        }
        miseAJourTimeout();
        
        return $_SESSION[ID_UTILISATEUR];
    }

    /**
     * Renvoie L'URL de l'image de profile de l'utilisateur passé en paramètre
     * @param string|null $name : par défaut null, si le nom d'utilisateur vaut null, il récupèreras celuis de l'utilisateur connecté, sinon il prendra celui de l'utilisateur passé en paramètre
     * @return string|false : le chemin de l'image si l'utilisateur existe/est connecté, renvoie false en cas d'erreur.
     */
    function getURLImageProfile($nomUtilisateur=null){
        if($nomUtilisateur == null){
            $nomUtilisateur = getNomUtilisateur();
            if($nomUtilisateur == false){ return false; }
        }else{
            if(!est_inscrit($nomUtilisateur)){ return false; }
        }

        $cheminImage = recupererCheminABS_PP($nomUtilisateur);

        if($cheminImage[0] != false){
            return substr($cheminImage[1], strlen(ROOT));
        }else{
            return "data/images/noImage.jpg";
        }
        
    }

    /**
     * Renvoie le nombre de DIY créer par l'utilisateur
     * @param string|null $nomUtilisateur=null : l'utilisateur en question, si la variable vaut null, récupère l'utilisateur courrant
     * @return int|false : le nombre de DIY créé par l'utilisateur, renvoie false si aucun utilisateur n'est trouvé/connecté
     */
    function getNombreDIYUtilisateur($nomUtilisateur=null){
        if($nomUtilisateur == NULL){
            $nomUtilisateur = getNomUtilisateur();
            if($nomUtilisateur == false){ return false; }
        }else{
            if(!est_inscrit($nomUtilisateur)){ return false; }
        }

        $stream = ouvrire_DIY();
        $compteur = 0;
        while(recupererInfo_CSV($stream, $nomUtilisateur, ID_COLONE_NOM_CREATEUR) != false){
            $compteur++;
        }

        return $compteur;

    }

    /**
     * Renvoie le nombre de commentaire créer par l'utilisateur
     * @param string|null $nomUtilisateur=null : l'utilisateur en question, si la variable vaut null, récupère l'utilisateur courrant
     * @return int|false : le nombre de commentaire écrit par l'utilisateur, renvoie false si aucun utilisateur n'est trouvé/connecté
     */
    function getNombreCommentaireUtilisateur($nomUtilisateur=null){
        if($nomUtilisateur == NULL){
            $nomUtilisateur = getNomUtilisateur();
            if($nomUtilisateur == false){ return false; }
        }else{
            if(!est_inscrit($nomUtilisateur)){ return false; }
        }

        $stream = ouvrir_commentaire();
        $compteur = 0;
        while(recupererInfo_CSV($stream, $nomUtilisateur, ID_COLONE_NOM_READACTEUR) != false){
            $compteur++;
        }

        return $compteur;

    }

    /**
     * Supprime l'utilisateur courrament connecté
     * Le mot de passe est demandé pour des raisons de sécurité, donc si l'utilisateur est déconnecté par time out, la fonction marcheras quand même
     * @param string $motDePasse : le mot de passe de l'utilisateur connecté
     * @param string $nomUtilisateur=null : le nom d'utilisateur d'un autre compte si l'utilisateur connecté est admin
     * @return true|int renvoie true si l'utilisateur a bien été supprimé, si une erreur est survenue, renvoie un code d'erreur :
     * - -1 : La session n'existe pas ou à été supprimé 
     * - -2 : L'utilisateur a déjà été supprimer ou n'existe pas
     * - -3 : Le mot de passe de l'utilisateur n'est pas le bon
     * - -4 : Une erreur inconue c'est produite à la suppresion
     * - -5 : Si supression d'un autre compte que le sien, l'utilisateur connecté n'est pas admin
     * - -6 : L'utilisateur a supprimer est super admin
     * - -7 : Si quelqu'un d'autre essaye de supprimer $nomUtilisateur, $nomUtilisateur est admin 
     */
    function suppUtilisateur($motDePasse, $nomUtilisateur=null){
        if(session_status() != PHP_SESSION_ACTIVE){
            session_start();
        }

        //La session de l'utilisateur n'existe pas/plus
        if(!isset($_SESSION[ID_UTILISATEUR])){ return -1; }
        
        if($nomUtilisateur == null){
            $nomUtilisateur = $_SESSION[ID_UTILISATEUR];
            
            //On vérifie que l'utilisateur existe toujours, sinon on ne peux pas le supprimer
            if(!est_inscrit($nomUtilisateur)) { return -2; }

            //On vérifie la correspondance du mot de passe
            if(!mdp_identique($nomUtilisateur, $motDePasse)){ return -3; }
        }else{
            //On vérifie que l'utilisateur existe toujours, sinon on ne peux pas le supprimer
            if(!est_inscrit($nomUtilisateur)) { return -2; }

            //On verifie est admin
            if(!estAdmin()){ return -5; }

            //On vérifie la correspondance du mot de passe
            if(!mdp_identique($_SESSION[ID_UTILISATEUR], $motDePasse)){ return -3; }

            if(estAdmin($nomUtilisateur)) { return -7; }
        }

        if(estSuperAdmin($nomUtilisateur)){ return -6; }
        
        //1ere étape, on supprime tout les DIYs posté par l'utilisateur     
        $diyUtlisateur = retourner_DIYUtilisateur($nomUtilisateur);
        foreach($diyUtlisateur as $diy){
            supprimerDIY($diy[0]);
        }

        //2eme étape, on supprime tout les commentaires utilisateur, et on mets a jour la notation des DIYs associé
        $commUtlisateur = tableu_IDsCommentaireUTILISTEUR($nomUtilisateur);
        foreach($commUtlisateur as $comm){
            enleverCommentaire($comm[0]);
        }

        if(supprimerUtilisateur($nomUtilisateur) == false){
            return -4;
        }
        
        return true;
    }



   /*
    * Fonction qui permet de faire une recherche simple dans la base de donnée utilisateur
    * 
    * @param string $nom : La chaine de recherche spécifié par l'admin
    * @return array : un chaine de dimension 2, plusieur ligne trié dans l'ordre croissant de poximité de la recherche. Les valeurs de chaques colones sont:
    * - [0] : La proximité avec le DIY
    * - [1] : La proximité maximal avec le DIY pour que le résultat soit gardé
    * - [2] : le nom/id de l'utilisateur
    * - [3] : le mot de passe hashé
    * - [4] : le status (0 => utilisateur, 1 => admin)
    * - [5] : le temps de préparation du DIY
    * - [6] : l'image de profil
    */
    function rechercheSimpleUtilisateur($nom){
        $flux = ouvrir_utilisateur();
        $motClefs = traiterString($nom);
        $motClefs = explode(" ", str_replace("  ", " ", $motClefs));

        $nbEchangeMax = 4;
        $besoinTraitementMotClef = false;
        $indiceValeur = 0;

        $resultats = rechercheInfo_CSV($flux, 'distanceLevenshtein', $motClefs, $nbEchangeMax, $indiceValeur, $besoinTraitementMotClef);
        return $resultats;
       
    }

    /**
     * Permet au super admin de promouvoir un utilisateur admin
     * @param string $nomUtilisateur : le nom d'utilisateur du nouvel administrateur
     * @return true|boolean : Si l'utilisateur spécifié a bien été ajouté en tant qu'admin, ou un code d'erreur
     * - -1 : utilisateur courrant n'est pas connecté
     * - -2 : utilisateur courrant n'est pas super admin
     * - -3 : utilisateur cible n'existe pas
     * - -4 : utilisateur cible est déjà administrateur
     * - -5 : erreur inconnue
     */
    function promouvoirAdmin($nomUtilisateur){
        if(!estConnecte()){
            return -1;
        }

        if(!estSuperAdmin()){
            return -2;
        }

        if(!est_inscrit($nomUtilisateur)){
            return -3;
        }

        if(estAdmin($nomUtilisateur)){
            return -4;
        }

        $result = changerImportance($nomUtilisateur, 1);

        if($result == false){
            return -5;
        }

        return true;
        
    }

    /**
     * Permet au super admin de destituer un admin
     * @param string $nomUtilisateur : le nom d'utilisateur de l'ancien administrateur
     * @return true|boolean : Si l'utilisateur spécifié a bien été supprimé en tant qu'admin, ou un code d'erreur
     * - -1 : utilisateur courrant n'est pas connecté
     * - -2 : utilisateur courrant n'est pas super admin
     * - -3 : utilisateur cible n'existe pas
     * - -4 : utlisateur cible n'est pas administrateur
     * - -5 : utilisateur cible est super administrateur
     * - -6 : erreur inconnue
     */
    function destituer($nomUtilisateur){
        if(!estConnecte()){
            return -1;
        }

        if(!estSuperAdmin()){
            return -2;
        }

        if(!est_inscrit($nomUtilisateur)){
            return -3;
        }

        if(!estAdmin($nomUtilisateur)){
            return -4;
        }

        if(estSuperAdmin($nomUtilisateur)){
            return -5;
        }

        $result = changerImportance($nomUtilisateur, 0);

        if($result == false){
            return -6;
        }

        return true;
    }

    /**
     * Permet au super admin de passer son status à un autre administrateur
     * @param string $nomUtilisateur : le nom d'utilisateur du nouveau super admin
     * @return true|boolean : Si l'utilisateur spécifié a bien été désigné comme nouveau super admin, ou un code d'erreur
     * - -1 : utilisateur courrant n'est pas connecté
     * - -2 : utilisateur courrant n'est pas super admin
     * - -3 : utilisateur cible n'existe pas
     * - -4 : utilisateur cible n'est pas administrateur
     * - -5 : erreur inconnue
     */
    function passationSuperAdmin($nomUtilisateur){
        if(!estConnecte()){
            return -1;
        }

        if(!estSuperAdmin()){
            return -2;
        }

        if(!est_inscrit($nomUtilisateur)){
            return -3;
        }

        if(!estAdmin($nomUtilisateur)){
            return -4;
        }

        $result = changerImportance($nomUtilisateur, 2);

        if($result == false){
            return -5;
        }

        $result = changerImportance(getNomUtilisateur(), 0);

        if($result == false){
            if(retourner_importance($nomUtilisateur) == 2 && retourner_importance(getNomUtilisateur()) == 0){
                $result = changerImportance($nomUtilisateur, 0);
            }
            return -5;
        }

        return true;
    }
?>
