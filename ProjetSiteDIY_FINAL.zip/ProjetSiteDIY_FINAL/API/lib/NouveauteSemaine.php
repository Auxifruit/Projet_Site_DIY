<?php
    include_once __DIR__."/UtilisateurUtils.php";
    function getNomDIYNouv(){
    	if(getInfoDIY(recuperer_InfoHebdo()[2]) == false){return "";}
        return getInfoDIY(recuperer_InfoHebdo()[2])[1];
    }

    function getTempsPrépaDIYNouv(){
    	if(getInfoDIY(recuperer_InfoHebdo()[2]) == false){return "0";}
        return getInfoDIY(recuperer_InfoHebdo()[2])[3];
    }

    function getCheminImageDIYNouv(){
    	if(getInfoDIY(recuperer_InfoHebdo()[2]) == false){return "/data/images/noImage.jpg";}
        return getInfoDIY(recuperer_InfoHebdo()[2])[5];
    }

    function getCheminDIYNouv(){
    	if(recuperer_InfoHebdo() == false){return "";}
        return" DIY_recette.php?Id=".recuperer_InfoHebdo()[2];
    }

    function getDifDIYNouv(){
    	if(getInfoDIY(recuperer_InfoHebdo()[2]) == false){return "";}
        return getInfoDIY(recuperer_InfoHebdo()[2])[4];
    }
?>
