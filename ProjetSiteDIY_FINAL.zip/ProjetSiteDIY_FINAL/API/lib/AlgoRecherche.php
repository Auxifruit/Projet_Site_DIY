<?php # -*- coding: utf-8 -*-
if(!defined("RECHRCHE_ALGO_PHP")){
    define("RECHRCHE_ALGO_PHP", "");

    define("COUT_SUBSTITUTION", 1);

    /**
     * Cette fonction vérifie si deux string sont identique
     * La valeur retourné est un tableau de valeur :
     * [0] -> l'égalité (0 identique, 1 different)
     * [1] -> la valeur max pour que ce soit égale, a savoir 1 (strictement inférieur a 1)
     * [2+i] -> la valeur du tableau ligneCSV[i] (si ligneCSV est un string, alors la valeur seras à l'index 2)
     * 
     * @param array|string $ligneCSV : un tableau de valeur ou une chaine de caractère
     * @param string $motClefs : Le string a comparé
     * @param int $nbEchangeMax : le nombre maximal d'opération qui peut être fait (inutile)
     * @param int $indiceValeur : l'indice de la phrase si $ligneCSV est un tableau
     * @param mixed ...$args : d'autre argument non utilisé dans cette fonction
     */
    function egaliteDesMots($ligneCSV, $mot, $nbEchangeMax, $indiceValeur, ...$args){
        $str = "";
        
        if(gettype($ligneCSV) == "string"){
            $str = $ligneCSV;
            $ligneCSV = [$ligneCSV];
        }else if(gettype($ligneCSV) == "array"){
            $str = $ligneCSV[$indiceValeur];
        }else{
            throw new InvalidArgumentException("Le type de ligne dans ".__DIR__.":distanceLevenshtein() devrait être string ou array, il est de type : ".gettype($ligneCSV));
        }

        if($str == $mot){
            array_unshift($ligneCSV, 0, 1);
        }else{
            array_unshift($ligneCSV, 1, 1);
        }

        return $ligneCSV;
    }

    /**
     * Cette fonction calcul une distance entre une liste de mot clef et une phrase
     * Cette distance consiste entre la somme des plus petites distances de Levenshtein de chaque mot de phrase pour chaque mot clef
     * Si la distance est plus grande que $nbEchangeMax, la distance pour ce mot clef seras de max(50, $nbEchangeMax+10)
     * La valeur retourné est un tableau de valeur :
     * [0] -> la distance calculé
     * [1] -> la distance maximal préféré pour être proche de ligneCSV
     * [2+i] -> la valeur du tableau ligneCSV[i] (si ligneCSV est un string, alors la valeur seras à l'index 2)
     * 
     * @param array|string $ligneCSV : un tableau de valeur ou une chaine de caractère
     * @param array $motClefs : un tableau qui contient la liste des mots clefs
     * @param int $nbEchangeMax : le nombre maximal d'opération qui peut être fait sur un mot d'une chaine pour être le mot clef
     * @param int $indiceValeur : l'indice de la phrase si $ligneCSV est un tableau
     * @param array|boolean $besoinTraitementMotClef : est ce que la liste de mot clef a besoin d'être traiter avant d'être utilisé. Il est recommandé de le faire avant et de mettre ce paramètre sur false pour gagner en rapidité
     */
    function distanceLevenshtein($ligneCSV, $motClefs, $nbEchangeMax, $indiceValeur, $besoinTraitementMotClef=false){
        $mots = "";
        $distanceTotal = 0;

        if(gettype($besoinTraitementMotClef) == 'array'){
            $besoinTraitementMotClef = $besoinTraitementMotClef[0];
        }
        
        //Traitement de la phrase
        if(gettype($ligneCSV) == "string"){
            $mots = traiterString($ligneCSV);
            $mots = explode(' ', $mots);

            $ligneCSV = [$ligneCSV];
        }else if(gettype($ligneCSV) == "array"){
            $mots = traiterString($ligneCSV[$indiceValeur]);
            $mots = explode(' ', $mots);
        }else{
            throw new InvalidArgumentException("Le type de ligne dans ".__DIR__.":distanceLevenshtein() devrait être string ou array, il est de type : ".gettype($ligneCSV));
        }
        if($besoinTraitementMotClef){
            foreach($motClefs as &$str){
                $str = traiterString($str);
            }
        }

        

        foreach($motClefs as $motClef){
            //Contient la distance minimal du motClef, par défaut a 50 car le coup si un mot n'est pas trouvé est de 50 par mot
            $distanceMinMotClef = max(50, $nbEchangeMax+10);

            foreach($mots as $mot){
                if(strlen($mot) > 1){
                    /* Début de l'algorthme de Levenshtein "classique"
                     * Normalement l'algorithme utilise une matrice D
                     * D est un tableau de strlen($mot)+1 ligne et strlen($motClef)+1 colone
                     * Mais au cours de l'algorithme, seul la ligne précédente est utilisé, rendant le reste inutile
                     * Cette algorithme optimise la mémoire en ne gardant que la ligne précédente
                     */

                    $lignePrecedente = array_fill(0, strlen($motClef)+1, 0);

                    /* La distance minimal possible entre le mot et le motClef
                     * Lors du calcule, il n'y a aucun moyen de reduire la distance pour une colone/ligne donnée
                     * Les seules opérations qui se font sont une des valeurs précédentes +1 ou +0 dans le cas de la substitution
                     * Donc la nouvelle distance min est la même ou la même +1 pour chaque passage a une nouvelle ligne
                     * Avec la ligne par défaut, la valeur minimal est 1 (car la ligne vaut 0 1 2 3 ...)
                    */
                    $distanceMinMot = 1;
    
                    $ligneActuel;
                    $coutSubstitution; $i; $j;

                    //Cette varaible vaut true si la distance minimal est plus grande que $distanceMinMotClef et $nbEchangeMax
                    $estTropDistant = false;
                    
            
                    //Initialisation de la première ligne
                    for($i = 0; $i < strlen($motClef)+2; $i++){
                        $lignePrecedente[$i] = $i;
                    }

                    $i = 1;
                    while($i < strlen($mot)+1 && !$estTropDistant){
                        //Initialisation de la ligne actuel
                        $ligneActuel = array_fill(0, strlen($motClef)+1, 0);
                        $ligneActuel[0] = $i;
            
                        for($j = 1; $j < strlen($motClef)+1; $j++){
                            //Calcule du coup de subtitution
                            if($mot[$i-1] == $motClef[$j-1]) { $coutSubstitution = 0; }
                            else { $coutSubstitution = COUT_SUBSTITUTION; }
            
                            $ligneActuel[$j] = min( $lignePrecedente[$j] + 1, $ligneActuel[$j-1] + 1, $lignePrecedente[$j-1] +  $coutSubstitution);

                            if($ligneActuel[$j] < $distanceMinMot){
                                $distanceMinMot = $ligneActuel[$j];
                            }
                        }
                        
                        if($distanceMinMot >= $distanceMinMotClef || $distanceMinMot >= $nbEchangeMax){
                            $estTropDistant = true;
                        }else{
                            //On change de ligne précédente
                            $lignePrecedente = $ligneActuel;
                            $i++;
                        }
                    }
            
                    if(!$estTropDistant && $lignePrecedente[strlen($motClef)] < $distanceMinMotClef){
                        $distanceMinMotClef = $lignePrecedente[strlen($motClef)];
                    }
                }
            }

            //Une fois le calcule de distance pour le mot clef terminé, on l'ajout a la distance total
            $distanceTotal = $distanceTotal + $distanceMinMotClef;
        }
        array_unshift($ligneCSV, $distanceTotal, max(50, $nbEchangeMax+10)*(intdiv(count($motClefs), 2) + count($motClefs)%2));
        return $ligneCSV;
        
    }

    /**
     * Fonction qui transforme une chaine de charactère pour pouvoir faire des opérations de recherche avec
     * @param string str: la chaine de charactère à traiter
     */
    function traiterString($str){
        $str = strtolower($str);
        return retirerMots(retirerPonctuation(remove_accents($str)));

    }

    /**
     * Retire la ponctuation d'une chaine de caractère
     * @param string str : la chaine de charactère d'entrée
    */
    function retirerPonctuation($str){
        $punctuation = array(",", ";", "?", ".", "/", ":", "!", "§", "*", "\"", "{", "}", "'", "[", "]");
        $str = str_replace($punctuation, "", $str);
        return $str;
    }

    /**
     * Retire les mots inutiles d'une chaine de charactère
     * Il est préférable de supprimer la ponctuation et les apostrophe avant
     * /!\ Les mot avec un apostrophe comme d'un sont chercher comme dun => il faut enlever les apostrophe avant
     * @param string str : la chaine de charactère d'entrée
     */
    function retirerMots($str){
        // \b : mot regex pour espace, début d'un string, fin d'un string, ...
        $motsInutile = array("/\bet\b/", "/\bou\b/", "/\bdun\b/", "/\bdune\b/", "/\bun\b/", "/\bune\b/", "/\ble\b/", "/\bla\b/", "/\bles\b/", "/\bdu\b/", "/\bde\b/");

        $str = preg_replace($motsInutile, "", $str);
        return $str;
    }

    /** 
     * Unaccent the input string string. An example string like `ÀØėÿᾜὨζὅБю`
     * will be translated to `AOeyIOzoBY`. More complete than :
     *   strtr( (string)$str,
     *          "ÀÁÂÃÄÅàáâãäåÒÓÔÕÖØòóôõöøÈÉÊËèéêëÇçÌÍÎÏìíîïÙÚÛÜùúûüÿÑñ",
     *          "aaaaaaaaaaaaooooooooooooeeeeeeeecciiiiiiiiuuuuuuuuynn" );
     *
     * @param $str input string
     * @param $utf8 if null, function will detect input string encoding
     * @return string input string without accent
     * 
     * @author Emmanuel Vaïsse (evaisse)
     * @link https://gist.github.com/evaisse/169594
     */
    function remove_accents( $str, $utf8=true )
    {
        $str = (string)$str;
        if( is_null($utf8) ) {
            if( !function_exists('mb_detect_encoding') ) {
                $utf8 = (strtolower( mb_detect_encoding($str) )=='utf-8');
            } else {
                $length = strlen($str);
                $utf8 = true;
                for ($i=0; $i < $length; $i++) {
                    $c = ord($str[$i]);
                    if ($c < 0x80) $n = 0; # 0bbbbbbb
                    elseif (($c & 0xE0) == 0xC0) $n=1; # 110bbbbb
                    elseif (($c & 0xF0) == 0xE0) $n=2; # 1110bbbb
                    elseif (($c & 0xF8) == 0xF0) $n=3; # 11110bbb
                    elseif (($c & 0xFC) == 0xF8) $n=4; # 111110bb
                    elseif (($c & 0xFE) == 0xFC) $n=5; # 1111110b
                    else return false; # Does not match any model
                    for ($j=0; $j<$n; $j++) { # n bytes matching 10bbbbbb follow ?
                        if ((++$i == $length)
                            || ((ord($str[$i]) & 0xC0) != 0x80)) {
                            $utf8 = false;
                            break;
                        }
                        
                    }
                }
            }
            
        }
        
        if(!$utf8)
            $str = utf8_encode($str);

        $transliteration = array(
        'Ĳ' => 'I', 'Ö' => 'O','Œ' => 'O','Ü' => 'U','ä' => 'a','æ' => 'a',
        'ĳ' => 'i','ö' => 'o','œ' => 'o','ü' => 'u','ß' => 's','ſ' => 's',
        'À' => 'A','Á' => 'A','Â' => 'A','Ã' => 'A','Ä' => 'A','Å' => 'A',
        'Æ' => 'A','Ā' => 'A','Ą' => 'A','Ă' => 'A','Ç' => 'C','Ć' => 'C',
        'Č' => 'C','Ĉ' => 'C','Ċ' => 'C','Ď' => 'D','Đ' => 'D','È' => 'E',
        'É' => 'E','Ê' => 'E','Ë' => 'E','Ē' => 'E','Ę' => 'E','Ě' => 'E',
        'Ĕ' => 'E','Ė' => 'E','Ĝ' => 'G','Ğ' => 'G','Ġ' => 'G','Ģ' => 'G',
        'Ĥ' => 'H','Ħ' => 'H','Ì' => 'I','Í' => 'I','Î' => 'I','Ï' => 'I',
        'Ī' => 'I','Ĩ' => 'I','Ĭ' => 'I','Į' => 'I','İ' => 'I','Ĵ' => 'J',
        'Ķ' => 'K','Ľ' => 'K','Ĺ' => 'K','Ļ' => 'K','Ŀ' => 'K','Ł' => 'L',
        'Ñ' => 'N','Ń' => 'N','Ň' => 'N','Ņ' => 'N','Ŋ' => 'N','Ò' => 'O',
        'Ó' => 'O','Ô' => 'O','Õ' => 'O','Ø' => 'O','Ō' => 'O','Ő' => 'O',
        'Ŏ' => 'O','Ŕ' => 'R','Ř' => 'R','Ŗ' => 'R','Ś' => 'S','Ş' => 'S',
        'Ŝ' => 'S','Ș' => 'S','Š' => 'S','Ť' => 'T','Ţ' => 'T','Ŧ' => 'T',
        'Ț' => 'T','Ù' => 'U','Ú' => 'U','Û' => 'U','Ū' => 'U','Ů' => 'U',
        'Ű' => 'U','Ŭ' => 'U','Ũ' => 'U','Ų' => 'U','Ŵ' => 'W','Ŷ' => 'Y',
        'Ÿ' => 'Y','Ý' => 'Y','Ź' => 'Z','Ż' => 'Z','Ž' => 'Z','à' => 'a',
        'á' => 'a','â' => 'a','ã' => 'a','ā' => 'a','ą' => 'a','ă' => 'a',
        'å' => 'a','ç' => 'c','ć' => 'c','č' => 'c','ĉ' => 'c','ċ' => 'c',
        'ď' => 'd','đ' => 'd','è' => 'e','é' => 'e','ê' => 'e','ë' => 'e',
        'ē' => 'e','ę' => 'e','ě' => 'e','ĕ' => 'e','ė' => 'e','ƒ' => 'f',
        'ĝ' => 'g','ğ' => 'g','ġ' => 'g','ģ' => 'g','ĥ' => 'h','ħ' => 'h',
        'ì' => 'i','í' => 'i','î' => 'i','ï' => 'i','ī' => 'i','ĩ' => 'i',
        'ĭ' => 'i','į' => 'i','ı' => 'i','ĵ' => 'j','ķ' => 'k','ĸ' => 'k',
        'ł' => 'l','ľ' => 'l','ĺ' => 'l','ļ' => 'l','ŀ' => 'l','ñ' => 'n',
        'ń' => 'n','ň' => 'n','ņ' => 'n','ŉ' => 'n','ŋ' => 'n','ò' => 'o',
        'ó' => 'o','ô' => 'o','õ' => 'o','ø' => 'o','ō' => 'o','ő' => 'o',
        'ŏ' => 'o','ŕ' => 'r','ř' => 'r','ŗ' => 'r','ś' => 's','š' => 's',
        'ť' => 't','ù' => 'u','ú' => 'u','û' => 'u','ū' => 'u','ů' => 'u',
        'ű' => 'u','ŭ' => 'u','ũ' => 'u','ų' => 'u','ŵ' => 'w','ÿ' => 'y',
        'ý' => 'y','ŷ' => 'y','ż' => 'z','ź' => 'z','ž' => 'z','Α' => 'A',
        'Ά' => 'A','Ἀ' => 'A','Ἁ' => 'A','Ἂ' => 'A','Ἃ' => 'A','Ἄ' => 'A',
        'Ἅ' => 'A','Ἆ' => 'A','Ἇ' => 'A','ᾈ' => 'A','ᾉ' => 'A','ᾊ' => 'A',
        'ᾋ' => 'A','ᾌ' => 'A','ᾍ' => 'A','ᾎ' => 'A','ᾏ' => 'A','Ᾰ' => 'A',
        'Ᾱ' => 'A','Ὰ' => 'A','ᾼ' => 'A','Β' => 'B','Γ' => 'G','Δ' => 'D',
        'Ε' => 'E','Έ' => 'E','Ἐ' => 'E','Ἑ' => 'E','Ἒ' => 'E','Ἓ' => 'E',
        'Ἔ' => 'E','Ἕ' => 'E','Ὲ' => 'E','Ζ' => 'Z','Η' => 'I','Ή' => 'I',
        'Ἠ' => 'I','Ἡ' => 'I','Ἢ' => 'I','Ἣ' => 'I','Ἤ' => 'I','Ἥ' => 'I',
        'Ἦ' => 'I','Ἧ' => 'I','ᾘ' => 'I','ᾙ' => 'I','ᾚ' => 'I','ᾛ' => 'I',
        'ᾜ' => 'I','ᾝ' => 'I','ᾞ' => 'I','ᾟ' => 'I','Ὴ' => 'I','ῌ' => 'I',
        'Θ' => 'T','Ι' => 'I','Ί' => 'I','Ϊ' => 'I','Ἰ' => 'I','Ἱ' => 'I',
        'Ἲ' => 'I','Ἳ' => 'I','Ἴ' => 'I','Ἵ' => 'I','Ἶ' => 'I','Ἷ' => 'I',
        'Ῐ' => 'I','Ῑ' => 'I','Ὶ' => 'I','Κ' => 'K','Λ' => 'L','Μ' => 'M',
        'Ν' => 'N','Ξ' => 'K','Ο' => 'O','Ό' => 'O','Ὀ' => 'O','Ὁ' => 'O',
        'Ὂ' => 'O','Ὃ' => 'O','Ὄ' => 'O','Ὅ' => 'O','Ὸ' => 'O','Π' => 'P',
        'Ρ' => 'R','Ῥ' => 'R','Σ' => 'S','Τ' => 'T','Υ' => 'Y','Ύ' => 'Y',
        'Ϋ' => 'Y','Ὑ' => 'Y','Ὓ' => 'Y','Ὕ' => 'Y','Ὗ' => 'Y','Ῠ' => 'Y',
        'Ῡ' => 'Y','Ὺ' => 'Y','Φ' => 'F','Χ' => 'X','Ψ' => 'P','Ω' => 'O',
        'Ώ' => 'O','Ὠ' => 'O','Ὡ' => 'O','Ὢ' => 'O','Ὣ' => 'O','Ὤ' => 'O',
        'Ὥ' => 'O','Ὦ' => 'O','Ὧ' => 'O','ᾨ' => 'O','ᾩ' => 'O','ᾪ' => 'O',
        'ᾫ' => 'O','ᾬ' => 'O','ᾭ' => 'O','ᾮ' => 'O','ᾯ' => 'O','Ὼ' => 'O',
        'ῼ' => 'O','α' => 'a','ά' => 'a','ἀ' => 'a','ἁ' => 'a','ἂ' => 'a',
        'ἃ' => 'a','ἄ' => 'a','ἅ' => 'a','ἆ' => 'a','ἇ' => 'a','ᾀ' => 'a',
        'ᾁ' => 'a','ᾂ' => 'a','ᾃ' => 'a','ᾄ' => 'a','ᾅ' => 'a','ᾆ' => 'a',
        'ᾇ' => 'a','ὰ' => 'a','ᾰ' => 'a','ᾱ' => 'a','ᾲ' => 'a','ᾳ' => 'a',
        'ᾴ' => 'a','ᾶ' => 'a','ᾷ' => 'a','β' => 'b','γ' => 'g','δ' => 'd',
        'ε' => 'e','έ' => 'e','ἐ' => 'e','ἑ' => 'e','ἒ' => 'e','ἓ' => 'e',
        'ἔ' => 'e','ἕ' => 'e','ὲ' => 'e','ζ' => 'z','η' => 'i','ή' => 'i',
        'ἠ' => 'i','ἡ' => 'i','ἢ' => 'i','ἣ' => 'i','ἤ' => 'i','ἥ' => 'i',
        'ἦ' => 'i','ἧ' => 'i','ᾐ' => 'i','ᾑ' => 'i','ᾒ' => 'i','ᾓ' => 'i',
        'ᾔ' => 'i','ᾕ' => 'i','ᾖ' => 'i','ᾗ' => 'i','ὴ' => 'i','ῂ' => 'i',
        'ῃ' => 'i','ῄ' => 'i','ῆ' => 'i','ῇ' => 'i','θ' => 't','ι' => 'i',
        'ί' => 'i','ϊ' => 'i','ΐ' => 'i','ἰ' => 'i','ἱ' => 'i','ἲ' => 'i',
        'ἳ' => 'i','ἴ' => 'i','ἵ' => 'i','ἶ' => 'i','ἷ' => 'i','ὶ' => 'i',
        'ῐ' => 'i','ῑ' => 'i','ῒ' => 'i','ῖ' => 'i','ῗ' => 'i','κ' => 'k',
        'λ' => 'l','μ' => 'm','ν' => 'n','ξ' => 'k','ο' => 'o','ό' => 'o',
        'ὀ' => 'o','ὁ' => 'o','ὂ' => 'o','ὃ' => 'o','ὄ' => 'o','ὅ' => 'o',
        'ὸ' => 'o','π' => 'p','ρ' => 'r','ῤ' => 'r','ῥ' => 'r','σ' => 's',
        'ς' => 's','τ' => 't','υ' => 'y','ύ' => 'y','ϋ' => 'y','ΰ' => 'y',
        'ὐ' => 'y','ὑ' => 'y','ὒ' => 'y','ὓ' => 'y','ὔ' => 'y','ὕ' => 'y',
        'ὖ' => 'y','ὗ' => 'y','ὺ' => 'y','ῠ' => 'y','ῡ' => 'y','ῢ' => 'y',
        'ῦ' => 'y','ῧ' => 'y','φ' => 'f','χ' => 'x','ψ' => 'p','ω' => 'o',
        'ώ' => 'o','ὠ' => 'o','ὡ' => 'o','ὢ' => 'o','ὣ' => 'o','ὤ' => 'o',
        'ὥ' => 'o','ὦ' => 'o','ὧ' => 'o','ᾠ' => 'o','ᾡ' => 'o','ᾢ' => 'o',
        'ᾣ' => 'o','ᾤ' => 'o','ᾥ' => 'o','ᾦ' => 'o','ᾧ' => 'o','ὼ' => 'o',
        'ῲ' => 'o','ῳ' => 'o','ῴ' => 'o','ῶ' => 'o','ῷ' => 'o','А' => 'A',
        'Б' => 'B','В' => 'V','Г' => 'G','Д' => 'D','Е' => 'E','Ё' => 'E',
        'Ж' => 'Z','З' => 'Z','И' => 'I','Й' => 'I','К' => 'K','Л' => 'L',
        'М' => 'M','Н' => 'N','О' => 'O','П' => 'P','Р' => 'R','С' => 'S',
        'Т' => 'T','У' => 'U','Ф' => 'F','Х' => 'K','Ц' => 'T','Ч' => 'C',
        'Ш' => 'S','Щ' => 'S','Ы' => 'Y','Э' => 'E','Ю' => 'Y','Я' => 'Y',
        'а' => 'A','б' => 'B','в' => 'V','г' => 'G','д' => 'D','е' => 'E',
        'ё' => 'E','ж' => 'Z','з' => 'Z','и' => 'I','й' => 'I','к' => 'K',
        'л' => 'L','м' => 'M','н' => 'N','о' => 'O','п' => 'P','р' => 'R',
        'с' => 'S','т' => 'T','у' => 'U','ф' => 'F','х' => 'K','ц' => 'T',
        'ч' => 'C','ш' => 'S','щ' => 'S','ы' => 'Y','э' => 'E','ю' => 'Y',
        'я' => 'Y','ð' => 'd','Ð' => 'D','þ' => 't','Þ' => 'T','ა' => 'a',
        'ბ' => 'b','გ' => 'g','დ' => 'd','ე' => 'e','ვ' => 'v','ზ' => 'z',
        'თ' => 't','ი' => 'i','კ' => 'k','ლ' => 'l','მ' => 'm','ნ' => 'n',
        'ო' => 'o','პ' => 'p','ჟ' => 'z','რ' => 'r','ს' => 's','ტ' => 't',
        'უ' => 'u','ფ' => 'p','ქ' => 'k','ღ' => 'g','ყ' => 'q','შ' => 's',
        'ჩ' => 'c','ც' => 't','ძ' => 'd','წ' => 't','ჭ' => 'c','ხ' => 'k',
        'ჯ' => 'j','ჰ' => 'h'
        );
        $str = str_replace( array_keys( $transliteration ),
                            array_values( $transliteration ),
                            $str);
        return $str;
    }
}

//distanceLevenshtein($ligneCSV, $motClefs, $nbEchangeMax, $besoinTraitementMotClef, $indiceValeur);
//distanceOpti($mot, $motClef, $nbEchangeMax);

/*echo "a : ".distanceLevenshtein("Fabrication d'une table basse avec du carton comprimé à plus de 10.000.000 tonnes !!!!!!!", ["bois", "table"], 5, false, 0)[0];
echo "<br>b : ".distanceLevenshtein("Fabrication d'une table basse avec du carton comprimé à plus de 10.000.000 tonnes !!!!!!!", ["bois", "table"], 5, false, 0)[1];
*/
?>