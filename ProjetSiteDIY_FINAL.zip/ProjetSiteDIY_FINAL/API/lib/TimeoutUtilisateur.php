<?php
if(!defined("TIMEOUT_UTILISATEUR_PHP")){
    include "VariableGlobal.php";

    define("TIMEOUT_UTILISATEUR_PHP", "");

    function estTimeOut(){
        if(isset($_SESSION["timeout"]) && time() > $_SESSION["timeout"]){
            return true;
        }
        return false;
    }

    function miseAJourTimeout(){
        $TEMPS_TIMEOUT  = 60*10; //10 minutes

        //Bug, l'utilisateur doit se reconnecter
        if(!isset($_SESSION[ID_UTILISATEUR])){
            header("Location:".URL_CONNECTION);
        }

        $_SESSION["timeout"]=time()+ $TEMPS_TIMEOUT; //Timeout de 10 minutes d'inactivité
    }
}
?>