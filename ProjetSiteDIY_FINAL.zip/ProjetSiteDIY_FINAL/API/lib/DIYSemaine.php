<?php
include_once __DIR__."/UtilisateurUtils.php";
    function getNomDIYSemaine(){
    	if(recuperer_InfoHebdo()[1] == "null"){return "";}
        return getInfoDIY(recuperer_InfoHebdo()[1])[1];
    }

    function getTempsPrépaDIYSemaine(){
    	if(recuperer_InfoHebdo()[1] == "null"){return "0";}
        return getInfoDIY(recuperer_InfoHebdo()[1])[3];
    }

    function getCheminImageDIYSemaine(){
    	if(recuperer_InfoHebdo()[1] == "null"){return "/data/images/noImage.jpg";}
        return getInfoDIY(recuperer_InfoHebdo()[1])[5];
    }

    function getCheminDIYSemaine(){
    	if(recuperer_InfoHebdo()[1] == "null"){return "";}
        return" DIY_recette.php?Id=".recuperer_InfoHebdo()[1];
    }

    function getDifDIYSemaine(){
    	if(recuperer_InfoHebdo()[1] == "null"){return "";}
        return getInfoDIY(recuperer_InfoHebdo()[1])[4];
    }
?>
