<?php
    include_once __DIR__."/TimeoutUtilisateur.php";
    include_once __DIR__."/VariableGlobal.php";
    include_once __DIR__."/UtilisateurUtils.php";
    include_once __DIR__."/AlgoRecherche.php";

    include_once __DIR__."/../serveur/DIY.php";
    include_once __DIR__."/../serveur/commentaire.php";

    /**
     * Fonction qui ajoute un DIY dans la base de donnée. Par défaut, le créateur du DIY est l'utilisateur courrament connecté
     * @param string $nom : le nom du DIY
     * @param int $duree : le temps de fabrication du DIY
     * @param int $difficulte : la difficulte entre 0 et NB_MAX_DIFFICULTE
     * @param string $cheminPhoto : le chemin de la photo du DIY sur le serveur
     * @param string $explicaiton : les exlications du DIY 
     * 
     * @return array|false : un tableau avec :
     * [0] : true, pour dire que la fonctoin c'est bien passé
     * [1] : l'id du commentaire
     * [2] : le chemin absolue du fichier d'instruction du DIY sur le serveur
     */
    function ajoutDIY($nom, $duree, $difficulte, $cheminPhoto, $explicaiton){
        if($nom == "" || strpos($nom, ';') != false || strpos($nom, '\n') != false){
            return false;
        }

        if($duree == "" || !is_numeric($duree) || strpos($duree, '\n') != false){
            return false;
        }

        if($difficulte == "" || !is_numeric($difficulte) || NB_MAX_DIFFICULTE < $difficulte  || $difficulte < 0|| strpos($difficulte, '\n') != false){
            return false;
        }

        $utilisateur = getNomUtilisateur();
        if($utilisateur == false){
            return false;
        }

        return ajouter_DIY($nom, $utilisateur, $duree, $difficulte, $cheminPhoto, $explicaiton);
    }

    /**
     * Fonction qui permet de faire une recherche simple dans la base de donnée
     * 
     * @param string $nom : La chaine de recherche spécifié par l'utilisateur
     * @return array : un chaine de dimension 2, plusieur ligne trié dans l'ordre croissant de poximité de la recherche. Les valeurs de chaques colones sont:
     * - [0] : La proximité avec le DIY
     * - [1] : La proximité maximmal avec le DIY pour que le résultat soit gardé
     * - [2] : l'id du DIY
     * - [3] : le nom du DIY
     * - [4] : le créateur du DIY
     * - [5] : le temps de préparation du DIY
     * - [6] : la difficulté du DIY
     * - [7] : le chemin de la photo du DIY
     * - [8] : les explications du DIY
     * - [9] : La notes du DIY
     */
    function rechercheSimpleDIY($nom){
        $flux = ouvrire_DIY();
        $motClefs = traiterString($nom);
        $motClefs = explode(" ", str_replace("  ", " ", $motClefs));

        $nbEchangeMax = 4;
        $besoinTraitementMotClef = false;
        $indiceValeur = 1;

        $resultats = rechercheInfo_CSV($flux, 'distanceLevenshtein', $motClefs, $nbEchangeMax, $indiceValeur, $besoinTraitementMotClef);
        foreach($resultats as &$result){
            $result[8] = recuperer_valeur_indication(ROOT.$result[8]);
        }
        return $resultats;
        
    }

    /**
     * Renvoie les infos d'un DIY
     * @param string $idDIY : l'id du DIY
     * @return array|false : un tableau avec les infos des DIY, si renvoie false, l'id n'existe pas
     * - [0] : l'id du DIY
     * - [1] : le nom du DIY
     * - [2] : le créateur du DIY
     * - [3] : le temps de préparation du DIY
     * - [4] : la difficulté du DIY
     * - [5] : le chemin de la photo du DIY
     * - [6] : les explications du DIY
     * - [7] : La notes du DIY
     */
    function getInfoDIY($idDIY){
        $data = retourner_InfoDIY($idDIY);
        if($data == false){ return false; }
        
        $data[6] = recuperer_valeur_indication(ROOT.$data[6]);
        return $data;
    }

    /**
     * Fonction qui permet de récupèrer les commentaires pour un DIY donnée
     * 
     * @param string $idDIY : l'id de DIY
     * @return array|bool : un tableau de dimension 2, pour chaque commentaire il y a à l'emplacement :
     * - [0] : le nom du commentateur
     * - [1] : son image de profile
     * - [2] : la note qu'il a donné au DIY
     * - [3] : le contenu du commentaire
     */
    function getCommentairesDIY($idDIY){
        //Vérification de l'existance du DIY
        if(retourner_InfoDIY($idDIY) == false){ return false; }

        $listeCommentaires = array();
        //Recherche des commentaires
        $listeCommentaires = retourner_Commentaires($idDIY);
        if($listeCommentaires[0] == false){ return false; }

        //On retire le triomphe de la fonction, on ne garde que le necessaires, à savoir la liste des commentaires 
        $listeCommentaires = $listeCommentaires[1];
        foreach($listeCommentaires as &$commentaire){
            array_splice($commentaire, 1, 0, getURLImageProfile($commentaire[0]));
        }

        return $listeCommentaires;
    }

    /**
     * Fonction qui permet de récupèrer un commentaire aléatoire pour un DIY donnée
     * 
     * @param string $idDIY : l'id de DIY
     * @return array|bool : un tableau de dimension 1, il y a à l'emplacement :
     * - [0] : le nom du commentateur
     * - [1] : son image de profile
     * - [2] : la note qu'il a donné au DIY
     * - [3] : le contenu du commentaire
     */
    function getRandomCommentaireDIY($idDIY){
        $listeCommentaires = getCommentairesDIY($idDIY);

        if($listeCommentaires == false){ return false; }

        return $listeCommentaires[rand(0, count($listeCommentaires)-1)];
    }

    /**
     * Fonction qui permet de récupèrer les ids de tous les DIY
     * @return array : une list contenant les ids de tous les DIY
     */
    function getToutIdDIY(){
        return retourner_idDIY();
    }

    /**
     * Fonction qui permet de récupèrer une liste de tout les DIY avec leur information
     * @return array : un tableau double dimension avec pour chaque DIY a l'indice :
     * - [0] : l'id du DIY
     * - [1] : le nom du DIY
     * - [2] : le créateur du DIY
     * - [3] : le temps de préparation du DIY
     * - [4] : la difficulté du DIY
     * - [5] : le chemin de la photo du DIY
     * - [6] : les explications du DIY
     * - [7] : La notes du DIY
     */
    function getToutDIY(){
        return getToutIdDIY();
    }

    function getDIYUtilisateur($nomUtilisateur){
        if(!est_inscrit($nomUtilisateur)){ return false; }
        return retourner_DIYUtilisateur($nomUtilisateur);
    }

    /**
     * Fonction qui permet de supprimer un commentaire, renvoi notamment false si l'utilisateur connecté n'est pas admin/l'utilisateur qui la posté
     * @param string $idCommentaire : l'id du commentaire
     * @return boolean : si la suppresion a réussit (true) ou non (false)
     */
    function suppCommentaire($idCommentaire){
        //Vérification connecté
        if(($nomUtilisateur = getNomUtilisateur()) == false){
            return false;

        //Vérificattion admin ou redacteur
        }else if(tableau_de_Commentaire($idCommentaire)[ID_COLONE_NOM_READACTEUR] != $nomUtilisateur && !estAdmin()){
            return false;
        }
        return supprimerCommentaire($idCommentaire);
    }

    /**
     * Fonction qui permet de supprimer un DIY, renvoi notamment false si l'utilisateur connecté n'est pas admin/l'utilisateur qui la posté
     * @param string $idDIY : l'ID du DIY a supprimer
     * @return boolean : si la suppression a réussit (true) ou non (false)
     */
    function suppDIY($idDIY){
        //Vérification connecté
        if(($nomUtilisateur = getNomUtilisateur()) == false){
            return false;
        
        //Vérification admin ou redacteur
        }else if(retourner_InfoDIY($idDIY)[ID_COLONE_NOM_CREATEUR] != $nomUtilisateur && !estAdmin()){
            return false;
        }
        //La fonction supprime tout les commentaires associé au DIY, pas besoin donc de le faire avant
        return supprimerDIY($idDIY);
    }

    /**
     * Fonction qui renvoie les DIYs à vérifier
     * Necessite d'être connecté en tant qu'administrateur
     * @return array|int un tableau a deux dimension contenant :
     * - [0] : l'id du DIY
     * - [1] : le nom du DIY
     * - [2] : le créateur du DIY
     * - [3] : le temps de préparation du DIY
     * - [4] : la difficulté du DIY
     * - [5] : le chemin de la photo du DIY
     * - [6] : les explications du DIY
     * - [7] : La notes du DIY
     * Ou un message d'erreur :
     * - -1 : l'utilisateur n'est pas connecté
     * - -2 : l'utilisateur n'est pas admin
     */
    function getDIYaVerifier(){
        if(!estConnecte()){
            return -1;
        }

        if(!estAdmin()){
            return -2;
        }

        $listeDIY = DIY_nonVerifie();
        foreach($listeDIY as &$diy){
            array_splice($diy, count($diy)-3, 2, recupererIndicationDIY($diy[0]));
        }

        return $listeDIY;
    }

    /**
     * Fonction qui renvoie les commentaires à vérifier
     * Necessite d'être connecté en tant qu'administrateur
     * @return array|int un tableau a deux dimension contenant :
     * - [0] : l'id du commentaire
     * - [1] : l'id du DIY ou il est posté
     * - [2] : l'id du redacteur
     * - [3] : l'URL de l'image du redacteur
     * - [4] : le contenue
     * - [5] : la note donnee par le commentateur
     * Ou un message d'erreur :
     * - -1 : l'utilisateur n'est pas connecté
     * - -2 : l'utilisateur n'est pas admin
     */
    function getCommaVerifier(){
        if(!estConnecte()){
            return -1;
        }

        if(!estAdmin()){
            return -2;
        }

        $listeComm = commentaire_nonVerifie();
        foreach($listeComm as &$comm){
            array_splice($comm, count($comm)-1, 1);
            $locaExpli = retourner_Commentaire($comm[ID_COLONE_ID_COMMENTAIRE]);
            $imageUitlisateur = getURLImageProfile($comm[ID_COLONE_NOM_READACTEUR]);
            array_splice($comm, count($comm)-2, 1, [$imageUitlisateur, $locaExpli]);
        }

        return $listeComm;
    }

    /**
     * Permet de valider un diy
     * @param string idDIY : l'id d'un DIY
     * @return true|int : true si tout c'est bien passé, ou un code d'erreur
     * - -1 : L'utilisateur n'est pas connecté
     * - -2 : L'utilisateur n'est pas admin
     * - -3 : Une erreur inconnue avec la base de donnée
     */
    function validerDIY($idDIY){
        if(!estConnecte()){
            return -1;
        }

        if(!estAdmin()){
            return -2;
        }

        return Basculer_ValiditeDIY($idDIY, 1) == true ? true:-3;
    }

     /**
     * Permet de valider un commentaire
     * @param string idComm : l'id d'un commentaire
     * @return true|int : true si tout c'est bien passé, ou un code d'erreur
     * - -1 : L'utilisateur n'est pas connecté
     * - -2 : L'utilisateur n'est pas admin
     * - -3 : Une erreur inconnue avec la base de donnée
     */
    function validerCommentaire($idComm){
        if(!estConnecte()){
            return -1;
        }

        if(!estAdmin()){
            return -2;
        }

        return Basucler_ValiditeCommentaire($idComm, 1) == true ? true:-3;
    }

    /**
     * Renvoie la date de création du DIY a partir de son ID
     * @param string $idDIY : l'id du DIY
     * @return string : la date de création du DIY sous form dd/mm/yyyy
     */
    function getDateCreationDIY($idDIY){
        return getDateCreation($idDIY);
    }

    /**
     * Renvoie la date de création d'un commentaire a partir de son ID
     * @param string $idComm : l'id du commentaire
     * @return string : la date de création du commentaire sous form dd/mm/yyyy
     */
    function getDateCreationCommentaire($idComm){
        return getDateCreation($idComm);
    }
?>