<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"  href="DIY_recettes.css">
    <title>Recette DIY</title>
</head>
<body>
    <?php
        include 'haut_page.php';
        include_once 'API/lib/DIYUtils.php';
        include_once 'API/serveur/master.php';

        $infodiy = getInfoDIY($_GET['Id']);
        $img = $infodiy[5];
        $nom = $infodiy[1];
        $duree = $infodiy[3];
        $note = $infodiy[8];
        $diff = $infodiy[4];
        $createur = $infodiy[2];
        $recette = $infodiy[6];
    
        echo "
        <div id='contient'>
         <img id='img' src='".$img."'  alt='img recette' >
            <div id='consigne'>
                <div id='consi'><h3><u>Consigne</h3></u></div>
                <div class='conss'>".$recette."</div>
            </div>               
        
            <div id='conteneur2' > 
                
                <div class='encart'><u>DIY:</u>".$nom."</div>

                <div class='encart'><u>Durée:</u>".$duree."min</div>

                <div class='encart'><u>Notes:</u>".$note."</div>

                <div class='encart'><u>Difficulté:</u>".$diff."</div>

                <div class='encart'><u>Créateur:</u>".$createur."</div>

                
            </div>";
        ?>

        </div>

        <div id="sepa"><h3>Espace commentaire</h3></div>
        
        <div id="second_conteneur" >

            <ul id="liste2">   
                <?php
                    if (isset($_POST['note_recette']) && isset($_POST['nouveau_commentaire'])) { 
                        ajouter_commentaire($_GET['Id'],getNomUtilisateur() ,$_POST['nouveau_commentaire'],$_POST['note_recette']  );
                        unset($_POST['nouveau_comm']);
                        unset($_POST['note_recette']);
                    }
                
                    if($estconnecter == true) {
                        echo "
                        <li class='ligne'>
        
                            <form method='post' action='DIY_recette.php?Id=".$_GET['Id']."' id='formdiy'>
                            
                                <img src='".getURLImageProfile()."' alt=phto >    
                            
                                
                                <div id='note_bout'>
                                    <div id='contient_note'>
                                        Note:
                                        <select name='note_recette' id='note_recette' >
                                            <option>0</option>
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                        </select>
                                    </div>
                                    <button id='boutoncom'>Envoyer votre commentaire</button>
                                </div>
                            
                                <textarea name='nouveau_commentaire' id='nouveau_comm' placeholder='Entrez votre commentaire'></textarea>
                            </form>
                        
                        </li>"; 

                    }

                    $com = getCommentairesDIY($_GET['Id']);


                    foreach($com as $commentaire) {
                        for($i = 0; $i < count($commentaire); $i++)
                        {
                            if ($i==0){
                                $u=$commentaire[$i];
                            }
                            elseif($i==1)
                            {
                                $img=$commentaire[$i];
                            }
                            elseif($i==2)
                            {
                                $note=$commentaire[$i];
                            }
                            elseif($i==3){
                                    $comm=$commentaire[$i];
                            }
                        }

                        echo "
                            <li class='ligne'>
                            ";
                        ?>
                        <img src='<?php echo $img?>' alt="">
                            <?php
                                echo "
                                
                                <div class='contient_com' >
                                    <div class='crea'>
                                        Utilisateur: ".$u."
                                    </div>
                                    <div class='note'>
                                        Notes: ".$note."/5
                                    </div>
                                </div>

                                <div class='comm'>".$comm."</div> 
                            
                                
                            </li>
                        ";              
                    }
                ?>
            </ul>
    </div>
    
</body>
</html>



