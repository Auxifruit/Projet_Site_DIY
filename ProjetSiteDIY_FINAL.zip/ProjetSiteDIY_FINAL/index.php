<?php include 'haut_page.php' ?>
<?php include 'API/lib/BricoloSemaine.php' ?>
<?php include 'API/lib/NouveauteSemaine.php' ?>
<?php include 'API/lib/DIYSemaine.php' ?>
<?php 
// initialisation des variable pour chacuns des rectangles (nouveauté )
$img_Nouv=getCheminImageDIYNouv();

$Nom_Nouv=getNomDIYNouv();

$Adresse_Nouv=getCheminDIYNouv();

$Dif_Nouv=getDifDIYNouv();

$temps_Nouv=getTempsPrépaDIYNouv();

// initialisation des variable pour chacuns des rectangles (meilleur bricoleur )

$img_bricolo= getCheminImageDIYBricolo();

$Nom_Bricolo=getNomDIYBricolo();

$Adresse_bricolo= getCheminDIYBricolo() ;

$temps_bricolo=  getTempsPrépaDIYBricolo();

// initialisation des variable pour chacuns des rectangles (recette de la semaine  )

$img_Sem= getCheminImageDIYSemaine();

$Nom_Sem=getNomDIYSemaine();

$Adresse_Sem=getCheminDIYSemaine();

$Dif_Sem=  getDifDIYSemaine() ;
 
$temps_Sem= getTempsPrépaDIYSemaine();

?>


<html lang="fr">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <link href="index.css" rel="stylesheet">
</head>
<body>   
    <div class="conteneur">  
        <div id="pageacc" name="nouveaudiy" >
            
            <h2>Nouveauté de la semaine : <?php echo " ".$Nom_Nouv." "?></h2>
        
            <br>
        
            <img src="<?php echo $img_Nouv ?>"id='imgrecettesem' name='recettesemaineimh'>
        
            <br>
            
            <h3>Niveau de difficulté : <?php echo $Dif_Nouv ?></h3> 
            
            <h3>Temps de préparation : <?php echo " ".$temps_Nouv." "?>min </h3> 
        
            <button onclick="window.location.href = '<?php echo $Adresse_Nouv ?>';"  class="buttonacc" >Accéder à la recette </button> 

        </div>

        <div id="bricolo"  >

            <h2>Bricolo de la semaine :  <?php echo $Nom_Bricolo ?></h2>
        
            <br>

            <img src="<?php echo " ".$img_bricolo." "?>" id="imgnricolo" >

            <br>

            <h3>Dernière recette :<?php echo " ".$Nom_Bricolo." "?> </h3> 
            
            <h3>Temps de préparation : <?php echo " ".$temps_bricolo." "?>min </h3> 
            
            <button onclick="window.location.href = '<?php echo $Adresse_bricolo ?>';"  class="buttonacc" >Accéder à la recette </button> 
        

        </div>

        <div id="pageacc3" name="nouveaudiy" >
            
            <h2>Nouveauté de la semaine : <?php echo $Nom_Sem ?></h2>
            
            <br>
            
            <img src="<?php echo $img_Sem ?>"  >
            
            <br>
            
            <h3>Niveau de difficulté :  <?php echo $Dif_Sem ?></h3> 
        
            <h3>Temps de préparation : <?php echo $temps_Sem ?> min </h3> 
        
            <button  onclick="window.location.href = '<?php echo $Adresse_Sem ?>';"  class="buttonacc" >Accéder à la recette </button>

        </div>

    </div>
</body>
</html>
