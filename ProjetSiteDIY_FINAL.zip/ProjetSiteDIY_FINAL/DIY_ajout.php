<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="DIY_ajout.css">
    <title>Ajout DIY</title>
</head>
<body>
    <?php
        include 'haut_page.php';
        include_once 'API/lib/UtilisateurUtils.php';
    ?>

    <link rel="shortcut icon" href="logo.png" type="image/x-icon/">

    <div id="boite">
        <h2>Ajout d'un DIY:</h2>
        <?php
            $nomUtilisateur = getNomUtilisateur();
            
            //Pour une raison X, l'utilisateur n'est plus connecté
            if($nomUtilisateur == false){
                header('Location: /connexion.php');
                exit();
            }
            echo "<span class='txt'>Pseudo du créateur:</span>";
            echo "<b> ".$nomUtilisateur."</b>";
		?>

        <div id="formulaire">

            <select id="pseudo" name="pseudo">
            <?php echo '<option value='.$nomUtilisateur.'></option>' ?>
            </select>

            <label for="nom" class="txt">Nom du DIY:</label><br>
            <input id="nom" name="nom" placeholder="Entrez le nom du DIY"><br><br>

            <label for="duree" class="txt">Durée du DIY en minute:</label><br>
            <input id="duree" name="duree" placeholder="Entrez la durée du DIY"><br><br>

            <label for="difficulte" class="txt">Difficulté du DIY:</label><br>
            <select id="difficulte" name="difficulte">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
            </select><br><br>

            <label for="recette" class="txt">Recette du DIY:</label><br>
            <textarea id="recette" name="recette" rows="4" cols="50" placeholder="Entrez la recette du DIY"></textarea><br><br>

            <label for="boutt_photo" class="txt" for="photo">Ajouter une photo du DIY:</label><br><br>
            <label for="photo" id="boutt_photo">Photo DIY</label>
            <span id="nom_photo"></span><br>
            <input type="file" id="photo" name="photo" accept=".jpg, .png" onchange="montrer_nom(event)"><br><br>

            <button type="submit" id="bouton" onclick="envoi()">Ajouter DIY</button><br><br>

        </div>

        <ul id="erreur"></ul>
    </div>

    <script>
        var montrer_nom = function(event) {
        	var image = document.getElementById('nom_photo');
        	image.innerHTML = document.getElementById('photo').files[0].name;
        };


        function envoi(){
        const image_files = document.getElementById('photo').files;

        var formData = new FormData();
        formData.append("nom", document.getElementById('nom').value);
        formData.append("duree", document.getElementById('duree').value);
        formData.append("difficulte", document.getElementById('difficulte').value);
        formData.append("recette", document.getElementById('recette').value);
        formData.append("photo", image_files[0]);

        let xhr = new XMLHttpRequest();

        xhr.onreadystatechange = function(){
            if (this.readyState == 4 && this.status == 200) {
                json=JSON.parse(this.responseText);
                if(json["AjoutReussie"] == true) {
                    window.location.replace("DIY.php");
                }
                else {
                    const erreur = document.getElementById("erreur");
                    while(erreur.firstChild) {
                        erreur.removeChild(erreur.lastChild);
                    }
                    json["MessageErreur"].forEach((message) => {
                        const li = document.createElement('li');
                        li.textContent = message;
                        document.getElementById("erreur").appendChild(li);
                    });
                    
                }
            }
        }
        xhr.open("POST", 'API/ajoutDIY.php', true);
        xhr.send(formData);
        }
    </script>

</body>
</html>