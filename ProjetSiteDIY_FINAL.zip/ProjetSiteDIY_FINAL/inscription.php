<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="identification.css">
    <title>Inscription</title>
    <script type="text/javascript" src="identification.js"></script>
</head>
<body>
    <?php include 'haut_page.php' ?>

    <div id="connexion">
        <h2 class="txt">Inscrivez-vous:</h2><br>
        <div id="bulle">
            <label class="txt">Nom d'utilisateur:</label><br><br>
            <input type="text" id="id" name="id" placeholder="Entrez votre nom d'utilisateur"><br><br>

            <label class="txt">Mot de passe:</label><br><br>
            <input type="password" id="mdp" name="mdp" placeholder="Entrez votre mot de passe"><br><br>

            <label class="txt">Entrez le mot de passe à nouveau:</label><br><br>
            <input type="password" id="vmdp" name="vmdp" placeholder="Entrez votre mot de passe"><br><br>

            <button type="button" id="bouton" onclick="inscription()">Inscription</button><br><br>

            <span class="txt">Déjà un compte ?</span> <a href="connexion.php">Connectez-vous</a><br><br>

            <span id="erreur"></span>

            
        </div>
    </div>

    <script>
        document.addEventListener("keyup", function(event) {
            if (event.keyCode === 13) {
                inscription();
            }
        });
    </script>
</body>
</html>
