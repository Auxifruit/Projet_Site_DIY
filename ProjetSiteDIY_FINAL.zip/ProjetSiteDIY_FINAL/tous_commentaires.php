<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="tous_commentaires.css">
    <title>Tous commentires</title>
</head>
<body>
    <?php 
    include 'haut_page.php';
    include_once __DIR__.'/API/serveur/commentaire.php';
    include_once __DIR__.'/API/lib/UtilisateurUtils.php';

    $nomUtilisateur = getNomUtilisateur();
						
	//Pour une raison X, l'utilisateur n'est plus connecté
	if($nomUtilisateur == false){
		header('Location: /connexion.php');
		exit();
	}

    $tab = tableu_IDsCommentaireUTILISTEUR($nomUtilisateur);
    $URLPhotoProfil = getURLImageProfile();

    ?>

    <div class="boite">
        <div id="utilisateur">
            <img id="pdp" src="<?php echo $URLPhotoProfil; ?>">
            <h2><u>Voici vos commentaires <?php echo "$nomUtilisateur" ?>:</u></h2>
        </div>
        
    </div>

    <div class="boite">

        <ul id="liste">
            
            <?php 
                if(!empty($tab)) {
                    foreach($tab as $ID_com) {
                        $info_DIY = array();
                        $info_DIY = retourner_InfoDIY(retournerID_Parent($ID_com));
                        echo "
                            <li class='info'>
                                <div class='nom'><u>Nom du DIY: ".$info_DIY[1]."</u></div>
                                <img class='photo' src='".$info_DIY[5]."'>
                                <div class='com_note'>
                                    <div class='com'>Commentaire: ".retourner_Commentaire($ID_com)."</div>
                                    <div class='note'>Note: ".note_commentaire($ID_com)."/5</div>
                                    <a href='DIY_recette.php?Id=".retournerID_Parent($ID_com)."'><button class='bouton'>Accéder au DIY</button></a>
                                </div>
                            </li>
                        ";
                    }
                }
                else {
                    echo "<li class='info'>
                            <div id='rien'><h3><u>Vous n'avez pas encore posté de commentaires !</u></h3></div>
                            <span>Cliquez ici pour accéder à la page des DIY:</span>
                            <a href='DIY.php'><button class='bouton'>Page DIY</button></a>
                        </li>";
                    }
            ?>
        </ul>
    </div>
</body>
</html> 
