<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="modif_pdp.css">
    <title>Modif PDP</title>
</head>
<body>
    <?php 
    include 'haut_page.php';
    include_once 'API/lib/UtilisateurUtils.php';

	$URLPhotoProfil = getURLImageProfile();
    ?>
    
    <div id="modif">
		<span class="txt">Photo de profil actuelle:</span><br><br>
		<img class="pdp" src="<?php echo $URLPhotoProfil; ?>">
        
		<hr>

        <span class="txt">Nouvelle photo de profil:</span><br><br><br>
        <label for="n_photo" class="bouton">Choisir une image</label>
        <input type="file" accept=".jpg, .png" name="n_photo" id="n_photo" onchange="montrer_image(event)"><br><br><br>
        <img id="sortie" width="200"/><br><br>

        <button class="bouton" onclick="envoi()">Valider</button>

        <ul id="erreur"></ul>
    </div>
</body>
<script>
    var montrer_image = function(event) {
    	var image = document.getElementById('sortie');
    	image.src = URL.createObjectURL(event.target.files[0]);
    };

    function envoi(){
        const image_files = document.getElementById('n_photo').files;

        var formData = new FormData();
        formData.append("n_photo", image_files[0]);

        let xhr = new XMLHttpRequest();

        xhr.onreadystatechange = function(){
            if (this.readyState == 4 && this.status == 200) {
                json=JSON.parse(this.responseText);
                if(json["AjoutReussie"] == true) {
                    window.location.replace("profil.php");
                }
                else {
                    const erreur = document.getElementById("erreur");
                    while(erreur.firstChild) {
                        erreur.removeChild(erreur.lastChild);
                    }
                    json["MessageErreur"].forEach((message) => {
                        const li = document.createElement('li');
                        li.textContent = message;
                        document.getElementById("erreur").appendChild(li);
                    });
                }
            }
        }
        xhr.open("POST", 'API/MajImageUtilisateur.php', true);
        xhr.send(formData);
        }
</script>
</html>