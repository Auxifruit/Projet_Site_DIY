<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="profil.css">
    <title>Profil</title>
</head>
<body>
    <?php 
    include 'haut_page.php';
    include_once 'API/lib/UtilisateurUtils.php';
	

	$URLPhotoProfil = getURLImageProfile();

	$nbDIYUtilisateur = getNombreDIYUtilisateur();

	$nbCommentaireUtilisateur = getNombreCommentaireUtilisateur();

	$nomUtilisateur = getNomUtilisateur();
						
	//Pour une raison X, l'utilisateur n'est plus connecté
	if($nomUtilisateur == false){
		header('Location: /connexion.php');
		exit();
	}
    ?>
    
    <div id="profil">
		
		<img id="pdp" src="<?php echo $URLPhotoProfil; ?>">
		<a href="modif_pdp.php"><button id="modif"><img id="modif_img" src="crayon.png"></button></a>

		<div class="txt">
			<?php echo $nomUtilisateur;?>
		</div>
		
		<hr>
		<div class="info_tab">
			<div class="label">Information basique:</div>
			<table class="tab">
				<tr>
					<td>Nom d'utilisateur:</td>
					<td><b><?php echo $nomUtilisateur;?></b></td>
				</tr>
				<tr>
					<td>Admin:</td>
					<td>
					<?php
						if(estAdmin()){
                    		echo "<b>OUI</b>";
						}
						else {
							echo "<b>NON</b>";
						}
					?>
					</td>
				</tr>
			</table>
		</div>
		<div class="info_tab">
			<div class="label">Information site:</div>
			<table class="tab">
				<tr>
					<td>Nombre de recettes:</td>
					<td><b><?php echo $nbDIYUtilisateur; ?></b></td>
				</tr>
				<tr>
					<td>Nombre de commentaires:</td>
					<td><b><?php echo $nbCommentaireUtilisateur; ?></b></td>
				</tr>
				<tr>
					<td><button id="com"><a href="tous_commentaires.php">Voir les commentaire postés</a></button></td>
				</tr>
			</table>
		</div>
    </div>

</body>
</html>