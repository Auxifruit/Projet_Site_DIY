function ChampVides() {
    var erreur=document.getElementById("erreur");
    var id=document.getElementById("id");
    var mdp=document.getElementById("mdp");
    var vide=false;
    erreur.innerHTML=("");
    if(id.value=="") {
        erreur.innerHTML=("Identifiant manquant");
        vide=true;
    }
    if(mdp.value=="") {
        if(vide==true) {
            erreur.innerHTML=("Identifiant et mot de passe manquants");
        }
        else {
            erreur.innerHTML=("Mot de passe manquant");
            vide=true;
        }
    }
    return vide;
}

function connexion() {
    if(ChampVides()){
        return;
    }
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange=function() {
        if (this.readyState == 4 && this.status == 200) {
            json=JSON.parse(this.responseText);
            if(json["ConnexionReussie"]==true) {
                document.location.href="/";
            }
            else {
                document.getElementById("erreur").innerHTML = json["MessageErreur"];
            }
        }
    };
    var id=document.getElementById("id").value;
    var mdp=document.getElementById("mdp").value;
    xhttp.open("post", "API/connexion.php", true);
    xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhttp.send("id="+id+"&mdp="+mdp);
}

function inscription() {
    if(ChampVides()){
        return;
    }
    if(document.getElementById("mdp").value!=document.getElementById("vmdp").value){
        erreur.innerHTML=("Les mots de passe ne sont pas identiques");
        return;
    }
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange=function() {
        if (this.readyState == 4 && this.status == 200) {
            json=JSON.parse(this.responseText);
            if(json["InscriptionReussie"]==true) {
                document.location.href="connexion.php";
            }
            else {
                document.getElementById("erreur").innerHTML = json["MessageErreur"];
            }
        }
    };
    var id=document.getElementById("id").value;
    var mdp=document.getElementById("mdp").value;
    var vmdp=document.getElementById("vmdp").value;
    xhttp.open("post", "API/inscription.php", true);
    xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhttp.send("id="+id+"&mdp="+mdp);
}
