<?php 


include_once 'haut_page.php' ; 
include_once 'API/lib/UtilisateurUtils.php';
include_once 'API/lib/DIYUtils.php';
include_once 'API/serveur/master.php';


   if (isset($_POST)){
  
   }

    if(isset($_POST['SUP_DIY'])){

        suppDIY($_POST['SUP_DIY']);
        unset($_POST);
    }

    if(isset($_POST['ADMIN_U'])){
            

        echo changerImportance($_POST['ADMIN_U'] ,1);
        unset($_POST);
    }

    if(isset($_POST['VALID_COM'])){
            
 validerCommentaire($_POST['VALID_COM']);

    }

    if(isset($_POST['VALID_DIY'])){
            

        validerDIY($_POST['VALID_DIY']);
  
    }


    if(isset($_POST['SADMIN_U'])){
            

        echo passationSuperAdmin($_POST['SADMIN_U']);
        unset($_POST);
        
    }

    if(isset($_POST['DADMIN_U'])){
            

        echo destituer($_POST['DADMIN_U']);
        unset($_POST);

    }
    if(isset($_POST['SUP_U'])){

      suppUtilisateur($_POST['mdp'],$_POST['SUP_U']);
    }$com_nonverif=getCommaVerifier();
$DIY_nonverif=DIY_nonVerifie();
?>

  
<html >
<head>
    <link rel="stylesheet" href="Page_A.css">
    <script type="text/javascript" src="Page_Admin.js"></script>
    <title>Document</title>
</head>
<body>
    
</body>
</html>
 <div id="test" >
 <div id="conteneur" >
    <img id="pdp_Admin" src="<?php  echo getURLImageProfile(); ?>" alt="">

    <div id="conteneur2" > 
                
                <div class="encart"><?php echo "Nombre de commentaire à vérifier" ;  ?></div>
                <div class="encart2" >  <?php echo sizeof($com_nonverif) ;?></div>
                <button type="submit" src="boutonadmin.png" class="button_recherche2" onclick="window.location.href = 'Page_Admin.php?R=<?php echo 'comm'  ?>';" > </button>
     
                <div class="encart"><?php echo "Nombre de DIY à vérifier" ;  ?></div>
                <div class="encart2" > <?php echo sizeof($DIY_nonverif) ;?> </div>
                <button type="submit" src="boutonadmin.png" class="button_recherche2" onclick="window.location.href = 'Page_Admin.php?R=<?php echo 'DIY'  ?>';" > </button>
     


               <form title="Rechercher des Admin " method="get" action="Page_Admin.php" id="form_Admin" name="Recherche_Admin" class="recherche">

                    
                    <input class="barre_rech_admin" type="text" placeholder="Rechercher des DIY" name="recherche"  size="30" >       
                    
                    <select name="value_rech" class="select_admin">
                     
                        <option value="DIY">DIY</option>
                        <option value="COMM">utilisateur</option>
                    </select>

                    <button type="submit" class="button_recherche2"> </button>
                </form>
                </form>




                
            </div>

</div>

<div id="boites">

<ul id="liste_admin" >

<?php if(isset($_GET['recherche'])){

?>


    
<?php 


$recherche= $_GET['recherche'];
$id_ligne=0;
if($_GET["value_rech"]=="DIY"){
 
    $diy = rechercheSimpleDIY($recherche);

    foreach($diy as $tab)
    {
        for($i = 0; $i < sizeof($tab); $i++)
        {
            
            if ($i==3){
                $nom=$tab[$i];
            }
            elseif($i==9)
            {
                $note=$tab[$i];
            }
            elseif($i==8)
            {
                $commentaire=$tab[$i];
            }
            elseif($i==6){
                $difficult=$tab[$i];
            }
            elseif($i==7)
            {
                $img=$tab[$i];
            }
            elseif($i==2){

                $Id=$tab[$i];
            
            }
            elseif($i==0){
                $proxi=$tab[$i];
            }
            elseif($i==4){
                $crea=$tab[$i];
            }
            else{
            }   
        }
    
            $id_ligne++;
 


            echo "<li class='ligne'id=".$id_ligne."> ; "  
            
     
            
            ?>

            
<img src="<?php echo $img ?>" alt="">
            
            <div class="note">
            
               Notes : <?php echo $note    ?>/5
            
            </div>
            
            <div class="diff">
            
                Difficulté : <?php echo $difficult ?>
            
            </div>
            <div class="diff">
            
            Pseudo : <?php echo $crea?>
        
        </div>

            <div class="comm">
            
             <div>   <?php echo $commentaire; 
             ?></div>
                
            </div>

            <div class="conteneurbouton">     
                
                <button  type="submit" onclick="window.location.href = 'DIY_recette.php?Id=<?php echo $Id ?>';"  class="buttonrech" >Accéder à la recette </button>

                <form method="POST" action="Page_Admin.php?recherche=<?php echo $_GET['recherche'] ;?>&value_rech=DIY">

                <input name="mdp" class="saisi_mdp" name='ADMIN_U' type="password" placeholder="entre ton mot de passe">
                    <button  type="submit"   class="buttonrech"name="SUP_U" value="<?php echo $crea; ?>"  >Supprimer Utilisateur </button>   
                    <button type="submit"   class="buttonrech" name="SUP_DIY" value="<?php echo $Id; ?>"  > Supprime DIY</button>
                    <?php
                      if (estAdmin($crea) ==false && estAdmin()==true  )  {
                                        
                        echo  "<button  type='submit'   class='buttonrech' name='ADMIN_U' value='$crea'  >Mettre Admin </button>";
                    
                    }
                    elseif (estAdmin($crea) ==true && estSuperAdmin()==true){
                        echo  "<button  type='submit'   class='buttonrech' name='DADMIN_U' value='$crea'  >Supprime Admin </button>";
                    }
                    if (estSuperAdmin()==true && estSuperAdmin($crea)==false && estAdmin($nom) ==true){
                        echo  "<button  type='submit'   class='buttonrech' name='SADMIN_U' value='$crea'  >Mettre Super Admin </button>";
                    }
                    
                    ?>
                    
                </form>
            </div>
            
            <svg width="100" height="100" id="bouton-proxy">

                <circle cx="50" cy="50" r="30" stroke="black" stroke-width="4" fill="#242423" />

                <text fill="white" font-size="50" font-family="ARIAL" x="34" y="65"><?php echo $proxi ;?></text>
                
            </svg>
           

               <?php   
            echo "</li>";

          
    }
}

if($_GET['value_rech']=="COMM"){

 
    $recherche= $_GET['recherche'];
    $diy = rechercheSimpleUtilisateur($recherche);
   
  
   foreach($diy as $tab)
   {
       for($i = 0; $i < sizeof($tab); $i++)
        {
           
           if ($i==2){
               $nom=$tab[$i];
           }
    
           elseif($i==4){
               $statut=$tab[$i];
           }
           elseif($i==5)
           {
               $img=$tab[$i];
           }
           elseif($i==0){
               $proxi=$tab[$i];
           }
   
           else{
            }
        }
     
        $nbDIYUtilisateur = getNombreDIYUtilisateur($nom);
        $nbCommentaireUtilisateur = getNombreCommentaireUtilisateur($nom);
   
   
  
           echo "<li class='ligne'>";     ?>
   
             
   <img src="<?php echo $img ?>" alt="">
            
            <div class="diff">
            
             Nombre de DIY : <?php echo $nbCommentaireUtilisateur; ?>
            
            </div>
            
            <div class="diff">
           
                Pseudo : <?php echo $nom; ?>

            </div>

            <div class="comm"  style="visibility: hidden;">
            
             
            </div>

    
            <div class="conteneurbouton">     
                
             
                <form method="POST" action="Page_Admin.php?recherche=<?php echo $_GET['recherche'] ;?>&value_rech=COMM">
                    <input name="mdp" class="saisi_mdp" name='ADMIN_U' type="password" placeholder="entre ton mot de passe">
                    <button  type="submit"   class="buttonrech"name="SUP_U" value="<?php echo $nom; ?>"  >Supprimer Utilisateur </button>
                    <?php 
                                        
                                        if (estAdmin($nom) ==false  && estAdmin()==true ) {
                                        
                                            echo  "<button  type='submit'   class='buttonrech' name='ADMIN_U' value='$nom'  >Mettre Admin </button>";
                                        
                                        }
                                        elseif (estAdmin($nom) ==true && estSuperAdmin()==true){
                                            echo  "<button  type='submit'   class='buttonrech' name='DADMIN_U' value='$nom'  >Supprime Admin </button>";
                                        }
                                        if (estSuperAdmin()==true && estSuperAdmin($nom)==false && estAdmin($nom) ==true) {
                                            echo  "<button  type='submit'   class='buttonrech' name='SADMIN_U' value='$nom'  >Mettre Super Admin </button>";
                                        }?>
                </form>
            </div>
            
            <svg width="100" height="100" id="bouton-proxy">

                <circle cx="50" cy="50" r="30" stroke="black" stroke-width="4" fill="#242423" />

                <text fill="white" font-size="50" font-family="ARIAL" x="34" y="65"><?php echo $proxi ;?></text>
                
            </svg>


               <?php 
           echo "</li>";
           
   }
 
   
   

}
echo"</ul>";
} 




if(isset($_GET["R"])){

if($_GET["R"]=="DIY"){
 
   

    foreach($DIY_nonverif as $tab)
    {
        for($i = 0; $i < sizeof($tab); $i++)
        {
            
            if ($i==0){
               $Id=$tab[$i];
            }
            elseif($i==1)
            { 
                $nom=$tab[$i];
              
            }
            elseif($i==2)
            {
                $crea=$tab[$i];
            }
            elseif($i==3){
                $difficult=$tab[$i];
            }
            elseif($i==4)
            {
              
            }
            elseif($i==5){
            
                $img=$tab[$i];
               
            }
            elseif($i==6){
               $commentaire=$tab[$i];
                $commentaire= recuperer_valeur_indication(ROOT.$commentaire);
            }
            
            elseif($i==7){
               


            }
            elseif($i==8){
               
                $note=$tab[$i];
                
            }
            else{
            }   
        }
    
  
        echo "<li class='ligne'>" ;  
            ?>

            
<img src="<?php echo $img ?>" alt="">
            
            <div class="diff">
            
               Notes : <?php echo $note    ?>/5
            
            </div>
            
            <div class="diff">
            
                Difficulté : <?php echo $difficult ?>
            
            </div>
            <div class="diff">
            
            Pseudo: <?php echo $crea ?>
        
            </div>



            <div class="comm">
            
             <div>   <?php echo $commentaire; 
             ?></div>
                
            </div>

            <div class="conteneurbouton">  
                
                    <button  type="submit" onclick="window.location.href = 'DIY_recette.php?Id=<?php echo $Id ?>';"  class="buttonrech" >Accéder à la recette </button>
                <form method="POST" action="Page_Admin.php?R=<?php echo $_GET['R'] ;?>">

                    <input name="mdp" class="saisi_mdp" name='ADMIN_U' type="password" placeholder="entre ton mot de passe">
                    <button  type="submit"   class="buttonrech"name="SUP_U" value="<?php echo $crea; ?>"  >Supprimer Utilisateur </button>
                    <button type="submit"   class="buttonrech" name="SUP_DIY" value="<?php echo $Id; ?>"  > Supprime DIY</button>
                    <button  type="submit"   class="buttonrech"name="VALID_DIY" value="<?php echo $Id; ?>"  >Valider le DIY </button>
                    <?php 
                                        if (estAdmin($crea) ==false && estAdmin()==true ) {
                                            echo  "<button  type='submit'   class='buttonrech' name='ADMIN_U' value='$crea'  >Mettre Admin </button>";
                                        }
                                        elseif (estAdmin($crea) ==true && estSuperAdmin()==true){
                                            echo  "<button  type='submit'   class='buttonrech' name='DADMIN_U' value='$crea'  >Supprime Admin </button>";
                                        }
                                        if (estSuperAdmin()==true && estSuperAdmin($crea)==false && estAdmin($nom) ==true){
                                            echo  "<button  type='submit'   class='buttonrech' name='SADMIN_U' value='$crea'  >Mettre Super Admin </button>";
                                        }
                    ?>
                </form>
            </div>
            
           
           

               <?php   
            echo "</li>";

          
    }
}

if($_GET["R"]=="comm"){
 
   
    
    foreach($com_nonverif as $tab)
    {
        for($i = 0; $i < sizeof($tab); $i++)
        {
            
            if ($i==0){
               $Id_com=$tab[$i];
            }
            elseif($i==1)
            { 
                $Id=$tab[$i];
              
            }
            elseif($i==2)
            { $nom=$tab[$i];
             
            }
            elseif($i==3)
            { $img=$tab[$i];
             
            }
            elseif($i==4){
                $commentaire=$tab[$i];
            }
            elseif($i==5)
            {
                $note=$tab[$i];
            }
            else{
            }   
        }
    
  
        echo "<li class='ligne'>" ;  
            ?>

            
<img src="<?php echo $img; ?>" alt="">
            
            <div class="note">
            
               Notes : <?php echo $note    ?>/5
            
            </div>
            
            <div class="diff">
            
                Pseudo : <?php echo $nom ?>
            
            </div>

            <div class="comm">
            
             <div>   <?php echo $commentaire; 
             ?></div>
                
            </div>

            <div class="conteneurbouton">  
                
                    <button  type="submit" onclick="window.location.href = 'DIY_recette.php?Id=<?php echo $Id ?>';"  class="buttonrech" >Accéder à la recette </button>
                <form method="POST" action="Page_Admin.php?R=<?php echo $_GET['R'] ;?>">

                    
                    <input name="mdp" class="saisi_mdp" name='ADMIN_U' type="password" placeholder="entre ton mot de passe">
                    <button  type="submit"   class="buttonrech"name="SUP_U" value="<?php echo $nom; ?>"  >Supprimer Utilisateur </button>
                    <button type="submit"   class="buttonrech" name="SUP_COM" value="<?php echo $Id_com; ?>"  > Supprime commentaire</button>
                    <button  type="submit"   class="buttonrech"name="VALID_COM" value="<?php echo $Id_com; ?>"  >Valider le commentaire </button>
                    <?php 
                    if (estAdmin($nom) ==false && estAdmin()==true  ) {
                        echo  "<button  type='submit'   class='buttonrech' name='ADMIN_U' value='$nom'  >Mettre Admin </button>";
                    }
                    elseif (estAdmin($nom) ==true && estSuperAdmin()==true){
                        echo  "<button  type='submit'   class='buttonrech' name='DADMIN_U' value='$nom'  >Supprime Admin  </button>";
                    }
                    if (estSuperAdmin()==true && estSuperAdmin($nom)==false && estAdmin($nom) ==true){
                        echo  "<button  type='submit'   class='buttonrech' name='SADMIN_U' value='$nom'  >Mettre Super Admin </button>";
                    }?>
                </form>
            </div>
            
           
           

               <?php   
            echo "</li>";

          
    }
}
}
?>
</div>
</div>