<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="haut_page.css">
</head>
<body>
    <link rel="shortcut icon" href="LOGO.png" type="image/x-icon"/>

    <div id="menu">
        <ul>
            <li><a class='lien' href="/">Accueil</a></li>

            <li><a class='lien' href="DIY.php">DIY</a></li>
            
            <?php
            include_once "API/lib/UtilisateurUtils.php";

            $estconnecter = estConnecte(); 
            if ($estconnecter == false ){
                echo "<li><a class='lien' href='connexion.php'>Connexion</a></li>" ; 

                echo "<li><a class='lien' href='inscription.php'>Inscription</a></li>";
            }
            else if ($estconnecter == true) {
                echo "<li><a class='lien' href='profil.php'>Profil</a></li>";
                echo "<li><a class='lien' href='DIY_ajout.php'>Ajout DIY</a></li>";
                echo "<li><a class='lien' href='API/deconnexion.php'>Déconnexion</a></li>";

                if(estAdmin()){
                    echo "<li><a class='lien' href='Page_Admin.php'>Bureau admin</a></li>";
                }
            }   

            ?>
            
            <li>
                <form title="Rechercher des DIY " method="get" action="recherche.php" id="form_recherche" name="Rechercher" class="recherche">
                    <input id="rba" type="text" placeholder="Rechercher des DIY" name="recherche"  size="30" id="barrederecherche">
                    <button id="button_recherche"> <img id="loupe" src="lopas.png" /></button>
                </form>
            </li>
        </ul>
        
    </div>
</body>
</html>
