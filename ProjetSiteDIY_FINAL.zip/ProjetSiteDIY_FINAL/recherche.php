<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="recherche.css" rel="stylesheet">
    <title>Recherche DIY</title>
</head>
<body>
    <?php

    include 'haut_page.php'; 
    include 'API/lib/DIYUtils.php' ;
    include 'API/serveur/master.php' ;

    ?>

    <div id=boite>

    <ul id="dd">
    <div class='vide'> </div>
        
    <?php 



$recherche= $_GET['recherche'];
$diy = rechercheSimpleDIY($recherche);
if(!empty($diy)) {
    foreach($diy as $tab) {
        for($i = 0; $i < sizeof($tab); $i++) {
            if($i==0){
                $proxi=$tab[$i];
            }
            elseif($i==2){
                $Id=$tab[$i];
            }
            elseif ($i==3){
                $nom=$tab[$i];
            }
            elseif ($i==5){
                $duree=$tab[$i];
            }
            elseif($i==6){
                $difficult=$tab[$i];
            }
            elseif($i==7) {
                $img=$tab[$i];
            }
            elseif($i==8) {
                $commentaire=$tab[$i];
            }
            elseif($i==9) {
                $note=$tab[$i];
            }
            else{
            }
        }
    
            echo "
            <li class='ligne'>
                <img class='photo' src='".$img."'>
                <div class='nom_note_diff_duree_bouton'>
                    <div class='nom'><h3><u>Nom du DIY:</u> ".$nom."</h3></div>
                    <div class='note_diff_duree'>
                        <div class='note'><u>Note:</u> ".$note."/5</div>
                        <div class='diff'><u>Difficulté:</u> ".$difficult."/5</div>
                        <div class='duree'><u>Duree:</u> ".$duree." minutes</div>
                    </div>
                    <div class='lien_proxi'>
                        <a href='DIY_recette.php?Id=".$Id."'><button class='bouton'>Accéder au DIY</button></a>
                        <div class='proxi'><u>Ecart avec la recherche:</u> ".$proxi."</div>
                    </div>
                </div>
            </li>";
            
        }
    }
    else {
        echo "
        <li class='info'>
            <div id='rien'><h3><u>Il n'y a aucun DIY sur le site !</u></h3></div>
            <span>Cliquez ici pour accéder à la page de création des DIY:</span>
            <a href='DIY_ajout.php'><button class='bouton'>Ajouter DIY</button></a>
        </li>
        ";
    }
        ?>

        </ul>
    
</div>
</body>
